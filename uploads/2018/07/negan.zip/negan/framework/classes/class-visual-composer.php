<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

class Negan_Visual_Composer{

    public $category;

    public static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct(){

        $this->category = esc_html__( 'La Studio', 'negan');

        if(!class_exists('Vc_Manager')) return false;

        add_action( 'vc_before_init', array( $this, 'vcBeforeInit') );
        add_action( 'vc_after_init', array( $this, 'vcAfterInit') );
        add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG , array( $this, 'customFilterTags' ), 10, 3 );
        add_filter('vc_tta_container_classes', array( $this, 'modifyTtaTabsClasses'), 10, 2 );

    }

    public function vcBeforeInit(){
        vc_automapper()->setDisabled( true );
        vc_manager()->disableUpdater( true );
        vc_manager()->setIsAsTheme( true );
        if(class_exists( 'WooCommerce' )){
            remove_action( 'wp_enqueue_scripts', 'vc_woocommerce_add_to_cart_script' );
        }
        add_filter('vc_map_get_param_defaults', array( $this, 'modifyCssAnimationValue' ), 10, 2);
    }

    public function vcAfterInit(){
        $this->overrideVcSection();
        //$this->overrideMessage();
        $this->overrideProgressBar();
        $this->overridePieChart();
        $this->overrideTtaAccordion();
        $this->overrideTtaTabs();
        $this->overrideTtaTour();
        $this->overrideTtaSection();

        if( function_exists('vc_set_default_editor_post_types') ){
            $list = array(
                'page',
                'post',
                'la_block',
                'la_portfolio'
            );
            vc_set_default_editor_post_types( $list );
        }
    }

    public function modifyCssAnimationValue($value, $param){
        if( 'css_animation' ==  $param['param_name'] && 'none' == $value){
            $value = '';
        }
        return $value;
    }

    public function customFilterTags($css_classes, $shortcode_name, $atts){
        if ( $shortcode_name == 'vc_progress_bar' ){
            if( isset($atts['display_type']) ){
                $css_classes .= ' vc_progress_bar_' . esc_attr($atts['display_type']);
            }
        }
        if ( $shortcode_name == 'vc_tta_tabs' || $shortcode_name == 'vc_tta_accordion' || $shortcode_name == 'vc_tta_tour' ){
            if( isset($atts['style']) && strpos($atts['style'], 'la-') !== false ){
                $css_classes = preg_replace('/ vc_tta-(o|shape|spacing|gap|color)[0-9a-zA-Z\_\-]+/','',$css_classes);
                if($shortcode_name == 'vc_tta_tabs'){
                    $css_classes .= ' vc_tta-o-no-fill';
                    $css_classes = str_replace('vc_tta-style-','tabs-',$css_classes);
                    $css_classes = str_replace('vc_general ','',$css_classes);
                }
                if($shortcode_name == 'vc_tta_tour'){
                    $css_classes = str_replace('vc_tta-style-','tour-',$css_classes);
                    $css_classes = str_replace('vc_general ','',$css_classes);
                }
            }
        }
        if($shortcode_name == 'vc_btn'){
            if(!empty($atts['style']) && in_array($atts['style'], array('modern', 'outline', 'custom', 'outline-custom'))){
                if( false !== strpos( $css_classes, 'vc_btn3-container')){
                    $css_classes .= ' la-vc-btn';
                }
            }
        }

        if ( $shortcode_name == 'vc_row' ) {
            $css_classes .= ' la_fp_slide la_fp_child_section';
        }

        return $css_classes;
    }

    public function overrideMessage(){
        $shortcode_name = 'vc_message';

        $shortcode_object = vc_get_shortcode($shortcode_name);
        $shortcode_params = $shortcode_object['params'];
        
        $icon_type = self::getParamIndex($shortcode_params,'icon_type');
        
        if($icon_type !== -1){
            $shortcode_params[$icon_type]['value'][esc_html__( 'None', 'negan' )] = 'none';
        }

        vc_map_update($shortcode_name , array(
            'category' => $this->category,
            'params' => $shortcode_params
        ));
    }

    public function overrideProgressBar(){
        vc_map_update( 'vc_progress_bar', array(
            'category' => $this->category
        ));
    }

    public function overridePieChart(){
        $shortcode_tag = 'vc_pie';
        $shortcode_object = vc_get_shortcode($shortcode_tag);
        $shortcode_params = $shortcode_object['params'];

        $shortcode_params = array(
            array(
                'type' => 'dropdown',
                'param_name' => 'style',
                'value' => array(
                    esc_html__( 'Style 01', 'negan' ) => '1',
                    esc_html__( 'Style 02', 'negan' ) => '2',
                ),
                'default'   => '1',
                'heading' => esc_html__( 'Style', 'negan' ),
                'description' => esc_html__( 'Select display style.', 'negan' )
            )
        ) + $shortcode_params ;

        vc_map_update( $shortcode_tag , array(
            'category' => $this->category,
            'params'   => $shortcode_params
        ));
    }

    public function overrideTtaAccordion(){
        vc_map_update('vc_tta_accordion' , array(
            'category' => $this->category,
            'params' => array(
                array(
                    'type' => 'dropdown',
                    'param_name' => 'style',
                    'value' => array(
                        esc_html__( 'Negan 01', 'negan' ) => 'la-1',
                        esc_html__( 'Negan 02', 'negan' ) => 'la-2',
                        esc_html__( 'Negan 03', 'negan' ) => 'la-3',
                        esc_html__( 'Classic', 'negan' ) => 'classic',
                        esc_html__( 'Modern', 'negan' ) => 'modern',
                        esc_html__( 'Flat', 'negan' ) => 'flat',
                        esc_html__( 'Outline', 'negan' ) => 'outline',
                    ),
                    'heading' => esc_html__( 'Style', 'negan' ),
                    'description' => esc_html__( 'Select accordion display style.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'shape',
                    'value' => array(
                        esc_html__( 'Rounded', 'negan' ) => 'rounded',
                        esc_html__( 'Square', 'negan' ) => 'square',
                        esc_html__( 'Round', 'negan' ) => 'round',
                    ),
                    'heading' => esc_html__( 'Shape', 'negan' ),
                    'description' => esc_html__( 'Select accordion shape.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'color',
                    'value' => getVcShared( 'colors-dashed' ),
                    'std' => 'grey',
                    'heading' => esc_html__( 'Color', 'negan' ),
                    'description' => esc_html__( 'Select accordion color.', 'negan' ),
                    'param_holder_class' => 'vc_colored-dropdown',
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'checkbox',
                    'param_name' => 'no_fill',
                    'heading' => esc_html__( 'Do not fill content area?', 'negan' ),
                    'description' => esc_html__( 'Do not fill content area with color.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'spacing',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => '',
                        '1px' => '1',
                        '2px' => '2',
                        '3px' => '3',
                        '4px' => '4',
                        '5px' => '5',
                        '10px' => '10',
                        '15px' => '15',
                        '20px' => '20',
                        '25px' => '25',
                        '30px' => '30',
                        '35px' => '35',
                    ),
                    'heading' => esc_html__( 'Spacing', 'negan' ),
                    'description' => esc_html__( 'Select accordion spacing.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'gap',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => '',
                        '1px' => '1',
                        '2px' => '2',
                        '3px' => '3',
                        '4px' => '4',
                        '5px' => '5',
                        '10px' => '10',
                        '15px' => '15',
                        '20px' => '20',
                        '25px' => '25',
                        '30px' => '30',
                        '35px' => '35',
                    ),
                    'heading' => esc_html__( 'Gap', 'negan' ),
                    'description' => esc_html__( 'Select accordion gap.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'c_align',
                    'value' => array(
                        esc_html__( 'Left', 'negan' ) => 'left',
                        esc_html__( 'Right', 'negan' ) => 'right',
                        esc_html__( 'Center', 'negan' ) => 'center',
                    ),
                    'heading' => esc_html__( 'Alignment', 'negan' ),
                    'description' => esc_html__( 'Select accordion section title alignment.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'autoplay',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => 'none',
                        '1' => '1',
                        '2' => '2',
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '10' => '10',
                        '20' => '20',
                        '30' => '30',
                        '40' => '40',
                        '50' => '50',
                        '60' => '60',
                    ),
                    'std' => 'none',
                    'heading' => esc_html__( 'Autoplay', 'negan' ),
                    'description' => esc_html__( 'Select auto rotate for accordion in seconds (Note: disabled by default).', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'checkbox',
                    'param_name' => 'collapsible_all',
                    'heading' => esc_html__( 'Allow collapse all?', 'negan' ),
                    'description' => esc_html__( 'Allow collapse all accordion sections.', 'negan' ),
                ),
                // Control Icons
                array(
                    'type' => 'dropdown',
                    'param_name' => 'c_icon',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => '',
                        esc_html__( 'Chevron', 'negan' ) => 'chevron',
                        esc_html__( 'Plus', 'negan' ) => 'plus',
                        esc_html__( 'Triangle', 'negan' ) => 'triangle',
                    ),
                    'std' => 'plus',
                    'heading' => esc_html__( 'Icon', 'negan' ),
                    'description' => esc_html__( 'Select accordion navigation icon.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'c_position',
                    'value' => array(
                        esc_html__( 'Left', 'negan' ) => 'left',
                        esc_html__( 'Right', 'negan' ) => 'right',
                    ),
                    'dependency' => array(
                        'element' => 'c_icon',
                        'not_empty' => true,
                    ),
                    'heading' => esc_html__( 'Position', 'negan' ),
                    'description' => esc_html__( 'Select accordion navigation icon position.', 'negan' ),
                ),
                // Control Icons END
                array(
                    'type' => 'textfield',
                    'param_name' => 'active_section',
                    'heading' => esc_html__( 'Active section', 'negan' ),
                    'value' => 1,
                    'description' => esc_html__( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'negan' ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'negan' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'negan' ),
                ),
            )
        ));
    }

    public function overrideTtaTabs(){
        vc_map_update( 'vc_tta_tabs', array(
            'category' => $this->category,
            'params' => array(
                array(
                    'type' => 'textfield',
                    'param_name' => 'title',
                    'heading' => __( 'Widget title', 'negan' ),
                    'description' => __( 'Enter text used as widget title (Note: located above content element).', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'style',
                    'value' => array(
                        esc_html__( 'Negan 01', 'negan' ) => 'la-1',
                        esc_html__( 'Negan 02', 'negan' ) => 'la-2',
                        esc_html__( 'Negan 03', 'negan' ) => 'la-3',
                        esc_html__( 'Negan 04', 'negan' ) => 'la-4',
                        esc_html__( 'Classic', 'negan' ) => 'classic',
                        esc_html__( 'Modern', 'negan' ) => 'modern',
                        esc_html__( 'Flat', 'negan' ) => 'flat',
                        esc_html__( 'Outline', 'negan' ) => 'outline',
                    ),
                    'heading' => esc_html__( 'Style', 'negan' ),
                    'description' => esc_html__( 'Select tabs display style.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'shape',
                    'value' => array(
                        esc_html__( 'Rounded', 'negan' ) => 'rounded',
                        esc_html__( 'Square', 'negan' ) => 'square',
                        esc_html__( 'Round', 'negan' ) => 'round',
                    ),
                    'heading' => esc_html__( 'Shape', 'negan' ),
                    'description' => esc_html__( 'Select tabs shape.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'color',
                    'heading' => esc_html__( 'Color', 'negan' ),
                    'description' => esc_html__( 'Select tabs color.', 'negan' ),
                    'value' => getVcShared( 'colors-dashed' ),
                    'std' => 'grey',
                    'param_holder_class' => 'vc_colored-dropdown',
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),

                array(
                    'type' => 'checkbox',
                    'param_name' => 'no_fill_content_area',
                    'heading' => esc_html__( 'Do not fill content area?', 'negan' ),
                    'std' => 'true',
                    'description' => esc_html__( 'Do not fill content area with color.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'spacing',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => '',
                        '1px' => '1',
                        '2px' => '2',
                        '3px' => '3',
                        '4px' => '4',
                        '5px' => '5',
                        '10px' => '10',
                        '15px' => '15',
                        '20px' => '20',
                        '25px' => '25',
                        '30px' => '30',
                        '35px' => '35',
                    ),
                    'heading' => esc_html__( 'Spacing', 'negan' ),
                    'description' => esc_html__( 'Select tabs spacing.', 'negan' ),
                    'std' => '',
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'gap',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => '',
                        '1px' => '1',
                        '2px' => '2',
                        '3px' => '3',
                        '4px' => '4',
                        '5px' => '5',
                        '10px' => '10',
                        '15px' => '15',
                        '20px' => '20',
                        '25px' => '25',
                        '30px' => '30',
                        '35px' => '35',
                    ),
                    'heading' => esc_html__( 'Gap', 'negan' ),
                    'description' => esc_html__( 'Select tabs gap.', 'negan' ),
                    'std' => '',
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'tab_position',
                    'value' => array(
                        esc_html__( 'Top', 'negan' ) => 'top',
                        esc_html__( 'Bottom', 'negan' ) => 'bottom',
                    ),
                    'heading' => esc_html__( 'Position', 'negan' ),
                    'description' => esc_html__( 'Select tabs navigation position.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'alignment',
                    'value' => array(
                        esc_html__( 'Left', 'negan' ) => 'left',
                        esc_html__( 'Right', 'negan' ) => 'right',
                        esc_html__( 'Center', 'negan' ) => 'center',
                    ),
                    'heading' => esc_html__( 'Alignment', 'negan' ),
                    'description' => esc_html__( 'Select tabs section title alignment.', 'negan' ),
                    'std' => 'center',
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'autoplay',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => 'none',
                        '1' => '1',
                        '2' => '2',
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '10' => '10',
                        '20' => '20',
                        '30' => '30',
                        '40' => '40',
                        '50' => '50',
                        '60' => '60',
                    ),
                    'std' => 'none',
                    'heading' => esc_html__( 'Autoplay', 'negan' ),
                    'description' => esc_html__( 'Select auto rotate for tabs in seconds (Note: disabled by default).', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'param_name' => 'active_section',
                    'heading' => esc_html__( 'Active section', 'negan' ),
                    'value' => 1,
                    'description' => esc_html__( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'pagination_style',
                    'value' => array(
                        esc_html__( 'None', 'negan' ) => '',
                        esc_html__( 'Square Dots', 'negan' ) => 'outline-square',
                        esc_html__( 'Radio Dots', 'negan' ) => 'outline-round',
                        esc_html__( 'Point Dots', 'negan' ) => 'flat-round',
                        esc_html__( 'Fill Square Dots', 'negan' ) => 'flat-square',
                        esc_html__( 'Rounded Fill Square Dots', 'negan' ) => 'flat-rounded',
                    ),
                    'heading' => esc_html__( 'Pagination style', 'negan' ),
                    'description' => esc_html__( 'Select pagination style.', 'negan' ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('classic','modern','flat','outline')
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'pagination_color',
                    'value' => getVcShared( 'colors-dashed' ),
                    'heading' => esc_html__( 'Pagination color', 'negan' ),
                    'description' => esc_html__( 'Select pagination color.', 'negan' ),
                    'param_holder_class' => 'vc_colored-dropdown',
                    'std' => 'grey',
                    'dependency' => array(
                        'element' => 'pagination_style',
                        'not_empty' => true,
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'negan' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'negan' ),
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__( 'CSS box', 'negan' ),
                    'param_name' => 'css',
                    'group' => esc_html__( 'Design Options', 'negan' ),
                ),
            )
        ));
    }

    public function overrideTtaSection(){
        $shortcode_tag = 'vc_tta_section';
        $shortcode_object = vc_get_shortcode($shortcode_tag);
        $shortcode_params = $shortcode_object['params'];
        $i_type_idx = self::getParamIndex($shortcode_params,'i_type');
        $el_class_idx = self::getParamIndex($shortcode_params,'el_class');
        if($i_type_idx !== -1 && $el_class_idx !== -1){
            $el_class = $shortcode_params[$el_class_idx];
            $shortcode_params[$i_type_idx]['value'][esc_html__('LaStudio Icon Outline', 'negan')] = 'la_icon_outline';
            $shortcode_params[$el_class_idx] = array (
                'type' => 'iconpicker',
                'heading' => __( 'Icon', 'negan' ),
                'param_name' => 'i_icon_la_icon_outline',
                'value' => 'la-icon design-2_image',
                'settings' => array(
                    'emptyIcon' => false,
                    'type' => 'la_icon_outline',
                    'iconsPerPage' => 50,
                ),
                'dependency' => array(
                    'element' => 'i_type',
                    'value' => 'la_icon_outline',
                )
            );
            $shortcode_params[] = $el_class;
            vc_map_update($shortcode_tag , array(
                'params' => $shortcode_params
            ));
        }
    }

    public function modifyTtaTabsClasses($classes, $atts){
        if(isset($atts['style']) && strpos($atts['style'],'la-') !== false && isset($atts['alignment'])){
            $classes[] = 'vc_tta-' . $atts['style'];
            $classes[] = 'vc_tta-alignment-' . $atts['alignment'];
        }
        return $classes;
    }

    public function overrideTtaTour(){
        vc_map_update( 'vc_tta_tour', array(
            'category' => $this->category,
            'params' => array(
                array(
                    'type' => 'dropdown',
                    'param_name' => 'style',
                    'value' => array(
                        esc_html__( 'Negan 01', 'negan' ) => 'la-1',
                    ),
                    'heading' => esc_html__( 'Style', 'negan' ),
                    'description' => esc_html__( 'Select tabs display style.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'tab_position',
                    'value' => array(
                        esc_html__( 'Left', 'negan' ) => 'left',
                        esc_html__( 'Right', 'negan' ) => 'right',
                    ),
                    'heading' => esc_html__( 'Position', 'negan' ),
                    'description' => esc_html__( 'Select tour navigation position.', 'negan' ),
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'alignment',
                    'value' => array(
                        esc_html__( 'Left', 'negan' ) => 'left',
                        esc_html__( 'Right', 'negan' ) => 'right',
                        esc_html__( 'Center', 'negan' ) => 'center',
                    ),
                    'heading' => esc_html__( 'Alignment', 'negan' ),
                    'description' => esc_html__( 'Select tabs section title alignment.', 'negan' ),
                    'std' => 'center',
                ),
                array(
                    'type' => 'hidden',
                    'param_name' => 'autoplay',
                    'std' => 'none',
                ),
                array(
                    'type' => 'dropdown',
                    'param_name' => 'controls_size',
                    'value' => array(
                        esc_html__( 'Auto', 'negan' ) => '',
                        esc_html__( 'Extra large', 'negan' ) => 'xl',
                        esc_html__( 'Large', 'negan' ) => 'lg',
                        esc_html__( 'Medium', 'negan' ) => 'md',
                        esc_html__( 'Small', 'negan' ) => 'sm',
                        esc_html__( 'Extra small', 'negan' ) => 'xs',
                    ),
                    'heading' => esc_html__( 'Navigation width', 'negan' ),
                    'description' => esc_html__( 'Select tour navigation width.', 'negan' ),
                ),

                array(
                    'type' => 'textfield',
                    'param_name' => 'active_section',
                    'heading' => esc_html__( 'Active section', 'negan' ),
                    'value' => 1,
                    'description' => esc_html__( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'negan' ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'negan' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'negan' ),
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__( 'CSS box', 'negan' ),
                    'param_name' => 'css',
                    'group' => esc_html__( 'Design Options', 'negan' ),
                ),
            )
        ));
    }

    public function overrideVcSection(){
        vc_add_params('vc_section', array(
            array(
                'type' => 'dropdown',
                'heading' => __('Section Behaviour', 'negan'),
                'param_name' => 'fp_auto_height',
                'admin_label' => true,
                'value' => array(
                    __('Full Height', 'negan') => 'off',
                    __('Auto Height', 'negan') => 'on',
                    __('Responsive Auto Height', 'negan') => 'responsive',
                    __('Top Fixed Header', 'negan') => 'fixed_top',
                    __('Bottom Fixed Footer', 'negan') => 'fixed_bottom',
                ),
                'description' => __('Select section row behaviour.', 'negan'),
                'group' => esc_html__('One Page Settings', 'negan'),
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => __('Anchor', 'negan'),
                'param_name' => 'fp_anchor',
                'admin_label'   => true,
                'value' => '',
                'description' => __('Enter an anchor (ID).', 'negan'),
                'dependency' => array('element' => 'fp_auto_height', 'value' => array('off', 'on', 'responsive')),
                'group' => esc_html__('One Page Settings', 'negan'),
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => __('Tooltip', 'negan'),
                'param_name' => 'fp_tooltip',
                'dependency' => array('element' => 'fp_auto_height', 'value' => array('off', 'on', 'responsive')),
                'value' => '',
                'group' => esc_html__('One Page Settings', 'negan'),
            ),
            array(
                'type' => 'checkbox',
                'class' => '',
                'heading' => __('Rows as Slides', 'negan'),
                'param_name' => 'fp_column_slide',
                'dependency' => array('element' => 'fp_auto_height', 'value' => array('off', 'on', 'responsive')),
                'value' => '',
                'group' => esc_html__('One Page Settings', 'negan'),
                'description' => __('Enable if you want to show each row in this section as slides.', 'negan'),
            ),
            array(
                'type' => 'checkbox',
                'class' => '',
                'heading' => __('No Scrollbars', 'negan'),
                'param_name' => 'fp_no_scrollbar',
                'dependency' => array('element' => 'fp_auto_height', 'value' => array('off', 'on', 'responsive')),
                'value' => '',
                'group' => esc_html__('One Page Settings', 'negan'),
                'description' => __('Enable if scrolloverflow is enabled but you don\'t want to show scrollbars for this section.', 'negan'),
            )
        ));
    }

    protected function arrayToObject($array) {
        if (!is_array($array)) {
            return $array;
        }
        $object = new stdClass();
        if (is_array($array) && count($array) > 0) {
            foreach ($array as $name=>$value) {
                $name = strtolower(trim($name));
                if (!empty($name)) {
                    $object->$name = $this->arrayToObject($value);
                }
            }
            return $object;
        }
        else {
            return false;
        }
    }

    public static function getParamIndex($array, $attr){
        foreach ($array as $index => $entry) {
            if ($entry['param_name'] == $attr) {
                return $index;
            }
        }
        return -1;
    }

}
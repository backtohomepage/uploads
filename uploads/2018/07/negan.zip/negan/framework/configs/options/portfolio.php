<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * Portfolio settings
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_options_section_portfolio( $sections )
{
    $sections['portfolio'] = array(
        'name' => 'portfolio_panel',
        'title' => esc_html__('Portfolio', 'negan'),
        'icon' => 'fa fa-th',
        'sections' => array(
            array(
                'name'      => 'portfolio_general_section',
                'title'     => esc_html__('General Setting', 'negan'),
                'icon'      => 'fa fa-check',
                'fields'    => array(
                    array(
                        'id'        => 'layout_archive_portfolio',
                        'type'      => 'image_select',
                        'title'     => esc_html__('Archive Portfolio Layout', 'negan'),
                        'desc'      => esc_html__('Controls the layout of archive portfolio page', 'negan'),
                        'default'   => 'col-1c',
                        'radio'     => true,
                        'options'   => Negan_Options::get_config_main_layout_opts(true, false)
                    ),
                    array(
                        'id'        => 'main_full_width_archive_portfolio',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'inherit',
                        'title'     => esc_html__('100% Main Width', 'negan'),
                        'desc'      => esc_html__('[Portfolio] Turn on to have the main area display at 100% width according to the window size. Turn off to follow site width.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts()
                    ),
                    array(
                        'id'            => 'main_space_archive_portfolio',
                        'type'          => 'spacing',
                        'title'         => esc_html__('Custom Main Space', 'negan'),
                        'desc'          => esc_html__('[Portfolio]Leave empty if you not need', 'negan'),
                        'unit' 	        => 'px'
                    ),
                    array(
                        'id'        => 'portfolio_display_type',
                        'default'   => 'grid',
                        'title'     => esc_html__('Display Type as', 'negan'),
                        'desc'      => esc_html__('Controls the type display of portfolio for the archive page', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            'grid'           => esc_html__('Grid', 'negan'),
                            'masonry'        => esc_html__('Masonry', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'portfolio_item_space',
                        'default'   => '0',
                        'title'     => esc_html__('Item Padding', 'negan'),
                        'desc'      => esc_html__('Select gap between item in grids', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            '0'         => esc_html__('0px', 'negan'),
                            '5'         => esc_html__('5px', 'negan'),
                            '10'        => esc_html__('10px', 'negan'),
                            '15'        => esc_html__('15px', 'negan'),
                            '20'        => esc_html__('20px', 'negan'),
                            '25'        => esc_html__('25px', 'negan'),
                            '30'        => esc_html__('30px', 'negan'),
                            '35'        => esc_html__('35px', 'negan'),
                        )
                    ),
                    array(
                        'id'        => 'portfolio_display_style',
                        'default'   => '1',
                        'title'     => esc_html__('Select Style', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            '1'           => esc_html__('Style 01', 'negan'),
                            '2'           => esc_html__('Style 02', 'negan'),
                            '3'           => esc_html__('Style 03', 'negan'),
                            '4'           => esc_html__('Style 04', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'portfolio_column',
                        'type'      => 'column_responsive',
                        'title'     => esc_html__('Portfolio Column', 'negan'),
                        'default'   => array(
                            'xlg' => 3,
                            'lg' => 3,
                            'md' => 2,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        )
                    ),
                    array(
                        'id'        => 'portfolio_per_page',
                        'type'      => 'number',
                        'default'   => 10,
                        'attributes'=> array(
                            'min' => 1,
                            'max' => 100
                        ),
                        'title'     => esc_html__('Total Portfolio will be display in a page', 'negan')
                    ),
                    array(
                        'id'        => 'portfolio_thumbnail_size',
                        'type'      => 'text',
                        'default'   => 'full',
                        'title'     => esc_html__('Portfolio Thumbnail size', 'negan'),
                        'desc'      => esc_html__('Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'single_portfolio_general_section',
                'title'     => esc_html__('Portfolio Single', 'negan'),
                'icon'      => 'fa fa-check',
                'fields'    => array(
                    array(
                        'id'        => 'layout_single_portfolio',
                        'type'      => 'image_select',
                        'title'     => esc_html__('Single Portfolio Layout', 'negan'),
                        'desc'      => esc_html__('Controls the layout of portfolio detail page', 'negan'),
                        'default'   => 'col-1c',
                        'radio'     => true,
                        'options'   => Negan_Options::get_config_main_layout_opts(true, false)
                    ),
                    array(
                        'id'        => 'single_portfolio_design',
                        'default'   => '1',
                        'title'     => esc_html__('Select Design', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            '1'           => esc_html__('Design 01', 'negan'),
                            '2'           => esc_html__('Design 02', 'negan'),
                            'use_vc'      => esc_html__('Show only post content', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'single_portfolio_nextprev',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'on',
                        'title'     => esc_html__('Show Next / Previous Portfolio', 'negan'),
                        'desc'      => esc_html__('Turn on to display next/previous portfolio', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    )
                )
            )
        )
    );
    return $sections;
}
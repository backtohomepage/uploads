<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * Fonts settings
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_options_section_fonts( $sections )
{
    $sections['fonts'] = array(
        'name'          => 'fonts_panel',
        'title'         => esc_html__('Typography', 'negan'),
        'icon'          => 'fa fa-font',
        'fields'        => array(
            array(
                'id'        => 'body_font_size',
                'type'      => 'slider',
                'default'    => 16,
                'title'     => esc_html__( 'Body Font Size', 'negan' ),
                'options'   => array(
                    'step'    => 1,
                    'min'     => 10,
                    'max'     => 20,
                    'unit'    => 'px'
                )
            ),
            array(
                'id'        => 'font_source',
                'type'      => 'radio',
                'default'   => '1',
                'title'     => esc_html__('Font Sources', 'negan'),
                'options'   => array(
                    '1' => esc_html__('Standard + Google Webfonts', 'negan'),
                    '2' => esc_html__('Google Custom', 'negan'),
                    '3' => esc_html__('Adobe Typekit', 'negan'),
                )
            ),
            array(
                'id'        => 'main_font',
                'type'      => 'typography',
                'default'   => array(
                    'family' => esc_html__('Roboto Condensed', 'negan'),
                    'font' => 'google',
                ),
                'title' => esc_html__('Body Font', 'negan'),
                'dependency' => array('font_source_1', '==', 'true'),
                'variant' => 'multi'
                //'variant' => 'multi'
            ),
            array(
                'id'        => 'secondary_font',
                'type'      => 'typography',
                'default'   => array(
                    'family' => esc_html__('Roboto Condensed', 'negan'),
                    'font' => 'google',
                ),
                'title' => esc_html__('Heading Font', 'negan'),
                'dependency' => array('font_source_1', '==', 'true'),
                'variant' => 'multi'
            ),
            array(
                'id'        => 'highlight_font',
                'type'      => 'typography',
                'default'   => array(
                    'family' => esc_html__('Playfair Display', 'negan'),
                    'font' => 'google',
                ),
                'title' => esc_html__('Three Font', 'negan'),
                'dependency' => array('font_source_1', '==', 'true'),
                'variant' => 'multi'
            ),
            array(
                'id'            => 'font_google_code',
                'type'          => 'text',
                'title'         => esc_html__('Font Google code', 'negan'),
                'dependency'    => array('font_source_2', '==', 'true')
            ),
            array(
                'id'            => 'main_google_font_face',
                'type'          => 'text',
                'title'         => esc_html__('Body Google Font Face', 'negan'),
                'after'         => 'e.g : open sans',
                'desc'          => esc_html__('Enter your Google Font Name for the theme\'s Body Typography', 'negan'),
                'dependency'    => array('font_source_2', '==', 'true')
            ),
            array(
                'id'            => 'secondary_google_font_face',
                'type'          => 'text',
                'title'         => esc_html__('Heading Google Font Face', 'negan'),
                'after'         => 'e.g : open sans',
                'desc'          => esc_html__('Enter your Google Font Name for the theme\'s Heading Typography', 'negan'),
                'dependency'    => array('font_source_2', '==', 'true')
            ),
            array(
                'id'            => 'highlight_google_font_face',
                'type'          => 'text',
                'title'         => esc_html__('Three Google Font Face', 'negan'),
                'after'         => 'e.g : open sans',
                'desc'          => esc_html__('Enter your Google Font Name for the theme\'s Three Typography', 'negan'),
                'dependency'    => array('font_source_2', '==', 'true')
            ),
            array(
                'id'            => 'font_typekit_kit_id',
                'type'          => 'text',
                'title'         => esc_html__('Typekit ID', 'negan'),
                'dependency'    => array('font_source_3', '==', 'true')
            ),
            array(
                'id'            => 'main_typekit_font_face',
                'type'          => 'text',
                'title'         => esc_html__('Body Typekit Font Face', 'negan'),
                'after'         => 'e.g : futura-pt',
                'desc'          => esc_html__('Enter your Typekit Font Name for the theme\'s Body Typography', 'negan'),
                'dependency'    => array('font_source_3', '==', 'true')
            ),
            array(
                'id'            => 'secondary_typekit_font_face',
                'type'          => 'text',
                'title'         => esc_html__('Heading Typekit Font Face', 'negan'),
                'after'         => 'e.g : futura-pt',
                'desc'          => esc_html__('Enter your Typekit Font Name for the theme\'s Heading Typography', 'negan'),
                'dependency'    => array('font_source_3', '==', 'true')
            ),
            array(
                'id'            => 'highlight_typekit_font_face',
                'type'          => 'text',
                'title'         => esc_html__('Three Typekit Font Face', 'negan'),
                'after'         => 'e.g : futura-pt',
                'desc'          => esc_html__('Enter your Typekit Font Name for the theme\'s Three Typography', 'negan'),
                'dependency'    => array('font_source_3', '==', 'true')
            )
        )
    );
    return $sections;
}
<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * Header settings
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_options_section_header( $sections ) {
    $sections['header'] = array(
        'name'          => 'header_panel',
        'title'         => esc_html__('Header', 'negan'),
        'icon'          => 'fa fa-arrow-up',
        'sections' => array(
            array(
                'name'      => 'header_layout_sections',
                'title'     => esc_html__('Layout', 'negan'),
                'icon'      => 'fa fa-cog',
                'fields'    => array(
                    array(
                        'id'        => 'header_layout',
                        'title'     => esc_html__('Header Layout', 'negan'),
                        'type'      => 'image_select',
                        'radio'     => true,
                        'class'     => 'la-radio-style',
                        'default'   => '1',
                        'desc'      => esc_html__('Controls the general layout of the header.', 'negan'),
                        'options'   => Negan_Options::get_config_header_layout_opts(true, false)
                    ),
                    array(
                        'id'        => 'header_full_width',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('100% Header Width', 'negan'),
                        'desc'      => esc_html__('Turn on to have the header area display at 100% width according to the window size. Turn off to follow site width.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false),
                        'info'      => esc_html__('This option do not allow for header type 5,6', 'negan')
                    ),
                    array(
                        'id'        => 'header_transparency',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Header Transparency', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false),
                        'info'      => esc_html__('This option do not allow for header type 5,6', 'negan')
                    ),
                    array(
                        'id'        => 'enable_header_sticky',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Enable Header Sticky', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false),
                        'info'      => esc_html__('This option do not allow for header type 5,6', 'negan')
                    ),
                    array(
                        'id'        => 'header_height',
                        'type'      => 'slider',
                        'default'    => '100px',
                        'title'     => esc_html__( 'Header Container Height', 'negan' ),
                        'options'   => array(
                            'step'    => 1,
                            'min'     => 50,
                            'max'     => 200,
                            'unit'    => 'px'
                        )
                    ),
                    array(
                        'id'        => 'header_sticky_height',
                        'type'      => 'slider',
                        'default'    => '80px',
                        'title'     => esc_html__( 'Header Sticky Container Height', 'negan' ),
                        'options'   => array(
                            'step'    => 1,
                            'min'     => 50,
                            'max'     => 200,
                            'unit'    => 'px'
                        )
                    )
                )
            ),
            array(
                'name'      => 'header_element_sections',
                'title'     => esc_html__('Elements', 'negan'),
                'icon'      => 'fa fa-cog',
                'fields'    => array(
                    array(
                        'id'        => 'header_show_cart',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Header Shopping Cart', 'negan'),
                        'desc'      => esc_html__('Show/Hide Shopping Cart in the Header.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'header_show_search',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Header Search Form', 'negan'),
                        'desc'      => esc_html__('Show/Hide Search Form in the Header.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'header_show_wishlist',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Header Wishlist Icon', 'negan'),
                        'desc'      => esc_html__('Show/Hide Wishlist Icon in the Header.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'header_show_menu_account',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Header Account Menu', 'negan'),
                        'desc'      => esc_html__('Show/Hide Account Menu Icon in the Header.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'header_show_menu_hamburger',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Header Hamburger Icon', 'negan'),
                        'desc'      => esc_html__('Show/Hide Hamburger Icon in the Header. The Aside sidebar will be displayed when clicked to icon', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'custom_header_text',
                        'type'      => 'ace_editor',
                        'mode'      => 'html',
                        'title'     => esc_html__('Custom HTML In Header', 'negan'),
                        'desc'      => esc_html__('This option working with header layout 2, header layout 7', 'negan')
                    ),
                    array(
                        'id'        => 'enable_header_top',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html__('Enable Header Top Area?', 'negan'),
                        'desc'      => esc_html__('Show/Hide Header Top Area in the Header.', 'negan'),
                        'options'   => array(
                            'no'            => esc_html__('Hide', 'negan'),
                            'yes'           => esc_html__('Yes', 'negan'),
                            'custom'        => esc_html__('Use Custom HTML', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'use_custom_header_top',
                        'type'      => 'ace_editor',
                        'mode'      => 'html',
                        'title'     => esc_html__('Custom HTML For Header Top', 'negan'),
                        'desc'      => esc_html__('Paste your custom HTML code here.', 'negan'),
                        'dependency'    => array('enable_header_top_custom', '==', true)
                    ),
                    array(
                        'id'        => 'header_top_elements',
                        'type'      => 'group',
                        'wrap_class'=> 'group-disable-clone',
                        'title'     => esc_html_x('Header Top Element', 'admin-view', 'negan'),
                        'button_title'    => esc_html_x('Add Element','admin-view', 'negan'),
                        'accordion_title' => 'type',
                        'max_item'  => 10,
                        'dependency'    => array('enable_header_top_yes', '==', true),
                        'fields'    => array(
                            array(
                                'id'        => 'type',
                                'type'      => 'select',
                                'title'     => esc_html_x('Type', 'admin-view', 'negan'),
                                'options'  => array(
                                    'dropdown_menu'     => esc_html_x('Dropdown Menu', 'admin-view', 'negan'),
                                    'text'              => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                    'link_icon'         => esc_html_x('Icon with link', 'admin-view', 'negan'),
                                    'link_text'         => esc_html_x('Text with link', 'admin-view', 'negan'),
                                    'searchbox'         => esc_html_x('Search box style 01', 'admin-view', 'negan'),
                                    'cart'              => esc_html_x('Cart Icon', 'admin-view', 'negan'),
                                    'wishlist'          => esc_html_x('Wishlist Icon', 'admin-view', 'negan'),
                                    'compare'           => esc_html_x('Compare Icon', 'admin-view', 'negan')
                                )
                            ),
                            array(
                                'id'            => 'icon',
                                'type'          => 'icon',
                                'default'       => 'fa fa-share',
                                'title'         => esc_html_x('Custom Icon', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_icon,link_text,dropdown_menu' )
                            ),
                            array(
                                'id'            => 'text',
                                'type'          => 'text',
                                'title'         => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_text,dropdown_menu')
                            ),
                            array(
                                'id'            => 'link',
                                'type'          => 'text',
                                'default'       => '#',
                                'title'         => esc_html_x('Link (URL)', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'link_icon,link_text,cart,wishlist,compare' )
                            ),
                            array(
                                'id'            => 'menu_id',
                                'type'          => 'select',
                                'title'         => esc_html_x('Select the menu','admin-view', 'negan'),
                                'class'         => 'chosen',
                                'options'       => 'tags',
                                'query_args'    => array(
                                    'orderby'   => 'name',
                                    'order'     => 'ASC',
                                    'taxonomies'=>  'nav_menu',
                                    'hide_empty'=> false
                                ),
                                'dependency'    => array( 'type', '==', 'dropdown_menu' )
                            ),
                            array(
                                'id'            => 'el_class',
                                'type'          => 'text',
                                'default'       => '',
                                'title'         => esc_html_x('Extra CSS class for item', 'admin-view', 'negan')
                            )
                        )
                    )
                )
            ),
            array(
                'name'      => 'header_default_styling_sections',
                'title'     => esc_html__('Default Header Styling', 'negan'),
                'icon'      => 'fa fa-paint-brush',
                'fields'    => array(
                    array(
                        'id'        => 'header_background',
                        'type'      => 'background',
                        'default'       => array(
                            'color' => '#fff'
                        ),
                        'title'     => esc_html__('Background', 'negan'),
                        'desc'      => esc_html__('for default header', 'negan'),
                    ),
                    array(
                        'id'        => 'header_text_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'title'     => esc_html__('Text Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan'),
                    ),
                    array(
                        'id'        => 'header_link_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'title'     => esc_html__('Link Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan'),
                    ),
                    array(
                        'id'        => 'header_link_hover_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'title'     => esc_html__('Link Hover Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan'),
                    ),
                    array(
                        'id'        => 'header_menu_bg',
                        'type'      => 'color_picker',
                        'default'   => '#000',
                        'title'     => esc_html__('Primary Menu Background Color', 'negan'),
                        'desc'      => esc_html__('Apply only for header style 03', 'negan'),
                    ),
                    array(
                        'id'        => 'mm_lv_1_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'title'     => esc_html__('Menu Level 1 Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan'),
                    ),
                    array(
                        'id'        => 'mm_lv_1_bg_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(0,0,0,0)',
                        'title'     => esc_html__('Menu Level 1 Background Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan')
                    ),
                    array(
                        'id'        => 'mm_lv_1_hover_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'title'     => esc_html__('Menu Level 1 Hover Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan')
                    ),
                    array(
                        'id'        => 'mm_lv_1_hover_bg_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(0,0,0,0)',
                        'title'     => esc_html__('Menu Level 1 Hover Background Color', 'negan'),
                        'desc'      => esc_html__('For default header', 'negan')
                    ),
                    array(
                        'type'    => 'notice',
                        'class'   => 'no-format la-section-title',
                        'content' => sprintf('<h3>%s</h3>', esc_html__('Header Top Styling', 'negan'))
                    ),
                    array(
                        'id'        => 'header_top_background_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(0,0,0,0)',
                        'title'     => esc_html__('Header Top Background Color', 'negan'),
                        'desc'      => esc_html__('For default header top', 'negan'),
                    ),
                    array(
                        'id'        => 'header_top_text_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(255,255,255,0.2)',
                        'title'     => esc_html__('Header Top Text Color', 'negan'),
                        'desc'      => esc_html__('For default header top', 'negan'),
                    ),
                    array(
                        'id'        => 'header_top_link_color',
                        'type'      => 'color_picker',
                        'default'   => '#fff',
                        'title'     => esc_html__('Header Top Link Color', 'negan'),
                        'desc'      => esc_html__('For default header top', 'negan'),
                    ),
                    array(
                        'id'        => 'header_top_link_hover_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'title'     => esc_html__('Header Top Link Hover Color', 'negan'),
                        'desc'      => esc_html__('For default header top', 'negan'),
                    )
                )
            ),
            array(
                'name'      => 'header_transparency_styling_sections',
                'title'     => esc_html__('Transparency Header Styling', 'negan'),
                'icon'      => 'fa fa-paint-brush',
                'fields'    => array(
                    array(
                        'id'        => 'transparency_header_background',
                        'type'      => 'background',
                        'default'       => array(
                            'color' => 'rgba(0,0,0,0)'
                        ),
                        'title'     => esc_html__('Background', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_header_text_color',
                        'type'      => 'color_picker',
                        'default'   => '#fff',
                        'title'     => esc_html__('Text Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_header_link_color',
                        'type'      => 'color_picker',
                        'default'   => '#fff',
                        'title'     => esc_html__('Link Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_header_link_hover_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'title'     => esc_html__('Link Hover Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_mm_lv_1_color',
                        'type'      => 'color_picker',
                        'default'   => '#fff',
                        'title'     => esc_html__('Menu Level 1 Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_mm_lv_1_bg_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(0,0,0,0)',
                        'title'     => esc_html__('Menu Level 1 Background Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_mm_lv_1_hover_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'title'     => esc_html__('Menu Level 1 Hover Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'id'        => 'transparency_mm_lv_1_hover_bg_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(0,0,0,0)',
                        'title'     => esc_html__('Menu Level 1 Hover Background Color', 'negan'),
                        'desc'      => esc_html__('For transparency header', 'negan')
                    ),
                    array(
                        'type'    => 'notice',
                        'class'   => 'no-format la-section-title',
                        'content' => sprintf('<h3>%s</h3>', esc_html__('Transparency Header Top Styling', 'negan'))
                    ),
                    array(
                        'id'        => 'transparency_header_top_background_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(0,0,0,0)',
                        'title'     => esc_html__('Header Top Background Color', 'negan'),
                        'desc'      => esc_html__('For transparency header top', 'negan'),
                    ),
                    array(
                        'id'        => 'transparency_header_top_text_color',
                        'type'      => 'color_picker',
                        'default'   => 'rgba(255,255,255,0.2)',
                        'title'     => esc_html__('Header Top Text Color', 'negan'),
                        'desc'      => esc_html__('For transparency header top', 'negan'),
                    ),
                    array(
                        'id'        => 'transparency_header_top_link_color',
                        'type'      => 'color_picker',
                        'default'   => '#fff',
                        'title'     => esc_html__('Header Top Link Color', 'negan'),
                        'desc'      => esc_html__('For transparency header top', 'negan'),
                    ),
                    array(
                        'id'        => 'transparency_header_top_link_hover_color',
                        'type'      => 'color_picker',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'title'     => esc_html__('Header Top Link Hover Color', 'negan'),
                        'desc'      => esc_html__('For transparency header top', 'negan'),
                    )
                )
            ),
            array(
                'name'      => 'header_offcanvas_styling_sections',
                'title'     => esc_html__('Aside Menu Styling', 'negan'),
                'icon'      => 'fa fa-paint-brush',
                'fields'    => array(
                    array(
                        'id'        => 'offcanvas_background',
                        'default'   => '#fff',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Background Color', 'negan'),
                        'desc'      => esc_html__('For Aside Header', 'negan')
                    ),
                    array(
                        'id'        => 'offcanvas_text_color',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Text color', 'negan'),
                        'desc'      => esc_html__('For Aside Header', 'negan')
                    ),
                    array(
                        'id'        => 'offcanvas_heading_color',
                        'default'   => Negan_Options::get_color_default('heading_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Heading color', 'negan'),
                        'desc'      => esc_html__('For Aside Header', 'negan')
                    ),
                    array(
                        'id'        => 'offcanvas_link_color',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link color', 'negan'),
                        'desc'      => esc_html__('For Aside Header', 'negan')
                    ),
                    array(
                        'id'        => 'offcanvas_link_hover_color',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Hover color', 'negan'),
                        'desc'      => esc_html__('For Aside Header', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'header_megamenu_styling_sections',
                'title'     => esc_html__('Mega Menu Styling', 'negan'),
                'icon'      => 'fa fa-bars',
                'fields'    => array(
                    array(
                        'id'        => 'mm_dropdown_bg',
                        'default'   => '#fff',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Background Color', 'negan'),
                        'desc'      => esc_html__('For type "DropDown"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_dropdown_link_color',
                        'default'   => Negan_Options::get_color_default('body_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Color', 'negan'),
                        'desc'      => esc_html__('For type "DropDown"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_dropdown_link_bg',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Background Color', 'negan'),
                        'desc'      => esc_html__('For type "DropDown"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_dropdown_link_hover_color',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Hover Color', 'negan'),
                        'desc'      => esc_html__('For type "DropDown"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_dropdown_link_hover_bg',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Hover Background Color', 'negan'),
                        'desc'      => esc_html__('For type "DropDown"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_wide_dropdown_bg',
                        'default'   => '#fff',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Background Color', 'negan'),
                        'desc'      => esc_html__('For type "Wide"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_wide_dropdown_heading_color',
                        'default'   => Negan_Options::get_color_default('heading_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Heading Color', 'negan'),
                        'desc'      => esc_html__('For type "Wide"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_wide_dropdown_link_color',
                        'default'   => Negan_Options::get_color_default('body_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Color', 'negan'),
                        'desc'      => esc_html__('For type "Wide"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_wide_dropdown_link_bg',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Background Color', 'negan'),
                        'desc'      => esc_html__('For type "Wide"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_wide_dropdown_link_hover_color',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Hover Color', 'negan'),
                        'desc'      => esc_html__('For type "Wide"', 'negan')
                    ),
                    array(
                        'id'        => 'mm_wide_dropdown_link_hover_bg',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Link Hover Background Color', 'negan'),
                        'desc'      => esc_html__('For type "Wide"', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'header_mobile_styling_sections',
                'title'     => esc_html__('Header Mobile', 'negan'),
                'icon'      => 'fa fa-paint-brush',
                'fields'    => array(
                    array(
                        'id'        => 'header_mb_layout',
                        'title'     => esc_html_x('Header Mobile Layout', 'admin-view', 'negan'),
                        'type'      => 'image_select',
                        'radio'     => true,
                        'class'     => 'la-radio-style',
                        'attributes'   => array(
                            'data-depend-id' => 'header_mb_layout',
                        ),
                        'default'   => '2',
                        'desc'      => esc_html_x('Controls the general layout of the header on mobile.', 'admin-view', 'negan'),
                        'options'   => array(
                            '1' => Negan::$template_dir_url . '/assets/images/theme_options/header-mobile-1.png',
                            '2' => Negan::$template_dir_url . '/assets/images/theme_options/header-mobile-2.png',
                            '3' => Negan::$template_dir_url . '/assets/images/theme_options/header-mobile-3.png',
                            '4' => Negan::$template_dir_url . '/assets/images/theme_options/header-mobile-4.png'
                        )
                    ),
                    array(
                        'id'        => 'mm_mb_effect',
                        'default'   => '1',
                        'title'     => esc_html_x('Mobile Menu Transition Effect', 'admin-view', 'negan'),
                        'desc'      => '<a target="_blank" href="//tympanus.net/Development/ResponsiveMultiLevelMenu/index.html">'. esc_html_x('See Demo', 'admin-view', 'negan') .'</a>',
                        'type'      => 'select',
                        'options'   => array(
                            '1'        => esc_html__('Effect 1', 'negan'),
                            '2'        => esc_html__('Effect 2', 'negan'),
                            '3'        => esc_html__('Effect 3', 'negan'),
                            '4'        => esc_html__('Effect 4', 'negan'),
                            '5'        => esc_html__('Effect 5', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'header_mb_component_1',
                        'type'      => 'group',
                        'wrap_class'=> 'group-disable-clone',
                        'title'     => esc_html_x('Header Mobile Icon Component 01', 'admin-view', 'negan'),
                        'button_title'    => esc_html_x('Add Icon Component ','admin-view', 'negan'),
                        'accordion_title' => 'type',
                        'max_item'  => 5,
                        'fields'    => array(
                            array(
                                'id'        => 'type',
                                'type'      => 'select',
                                'title'     => esc_html_x('Type', 'admin-view', 'negan'),
                                'options'  => array(
                                    'primary_menu'      => esc_html_x('Toggle Primary Menu', 'admin-view', 'negan'),
                                    'aside'             => esc_html_x('Toggle Aside Sidebar', 'admin-view', 'negan'),
                                    'dropdown_menu'     => esc_html_x('Dropdown Menu', 'admin-view', 'negan'),
                                    'text'              => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                    'link_icon'         => esc_html_x('Icon with link', 'admin-view', 'negan'),
                                    'link_text'         => esc_html_x('Text with link', 'admin-view', 'negan'),
                                    'searchbox'         => esc_html_x('Search box style 01', 'admin-view', 'negan'),
                                    'cart'              => esc_html_x('Cart Icon', 'admin-view', 'negan'),
                                    'wishlist'          => esc_html_x('Wishlist Icon', 'admin-view', 'negan'),
                                    'compare'           => esc_html_x('Compare Icon', 'admin-view', 'negan')
                                )
                            ),
                            array(
                                'id'            => 'icon',
                                'type'          => 'icon',
                                'default'       => 'fa fa-share',
                                'title'         => esc_html_x('Custom Icon', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_icon,link_text,dropdown_menu,aside' )
                            ),
                            array(
                                'id'            => 'text',
                                'type'          => 'text',
                                'title'         => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_text,dropdown_menu' )
                            ),
                            array(
                                'id'            => 'link',
                                'type'          => 'text',
                                'default'       => '#',
                                'title'         => esc_html_x('Link (URL)', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'link_icon,link_text,cart,wishlist,compare' )
                            ),
                            array(
                                'id'            => 'menu_id',
                                'type'          => 'select',
                                'title'         => esc_html_x('Select the menu','admin-view', 'negan'),
                                'class'         => 'chosen',
                                'options'       => 'tags',
                                'query_args'    => array(
                                    'orderby'   => 'name',
                                    'order'     => 'ASC',
                                    'taxonomies'=>  'nav_menu',
                                    'hide_empty'=> false
                                ),
                                'dependency'    => array( 'type', '==', 'dropdown_menu' )
                            ),
                            array(
                                'id'            => 'el_class',
                                'type'          => 'text',
                                'default'       => '',
                                'title'         => esc_html_x('Extra CSS class for item', 'admin-view', 'negan')
                            )
                        ),
                        'default' => array(
                            array(
                                'type' => 'searchbox'
                            ),
                            array(
                                'type' => 'primary_menu'
                            )
                        )
                    ),
                    array(
                        'id'        => 'header_mb_component_2',
                        'type'      => 'group',
                        'wrap_class'=> 'group-disable-clone',
                        'title'     => esc_html_x('Header Mobile Icon Component 02', 'admin-view', 'negan'),
                        'button_title'    => esc_html_x('Add Icon Component ','admin-view', 'negan'),
                        'accordion_title' => 'type',
                        'dependency'    => array('header_mb_layout', 'any', '1,4'),
                        'max_item'  => 5,
                        'fields'    => array(
                            array(
                                'id'        => 'type',
                                'type'      => 'select',
                                'title'     => esc_html_x('Type', 'admin-view', 'negan'),
                                'options'  => array(
                                    'primary_menu'      => esc_html_x('Toggle Primary Menu', 'admin-view', 'negan'),
                                    'aside'             => esc_html_x('Toggle Aside Sidebar', 'admin-view', 'negan'),
                                    'dropdown_menu'     => esc_html_x('Dropdown Menu', 'admin-view', 'negan'),
                                    'text'              => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                    'link_icon'         => esc_html_x('Icon with link', 'admin-view', 'negan'),
                                    'link_text'         => esc_html_x('Text with link', 'admin-view', 'negan'),
                                    'searchbox'          => esc_html_x('Search box style 01', 'admin-view', 'negan'),
                                    'cart'              => esc_html_x('Cart Icon', 'admin-view', 'negan'),
                                    'wishlist'          => esc_html_x('Wishlist Icon', 'admin-view', 'negan'),
                                    'compare'           => esc_html_x('Compare Icon', 'admin-view', 'negan')
                                )
                            ),
                            array(
                                'id'            => 'icon',
                                'type'          => 'icon',
                                'default'       => 'fa fa-share',
                                'title'         => esc_html_x('Custom Icon', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_icon,link_text,dropdown_menu,aside' )
                            ),
                            array(
                                'id'            => 'text',
                                'type'          => 'text',
                                'title'         => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_text,dropdown_menu' )
                            ),
                            array(
                                'id'            => 'link',
                                'type'          => 'text',
                                'default'       => '#',
                                'title'         => esc_html_x('Link (URL)', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'link_icon,link_text,cart,wishlist,compare' )
                            ),
                            array(
                                'id'            => 'menu_id',
                                'type'          => 'select',
                                'title'         => esc_html_x('Select the menu','admin-view', 'negan'),
                                'class'         => 'chosen',
                                'options'       => 'tags',
                                'query_args'    => array(
                                    'orderby'   => 'name',
                                    'order'     => 'ASC',
                                    'taxonomies'=>  'nav_menu',
                                    'hide_empty'=> false
                                ),
                                'dependency'    => array( 'type', '==', 'dropdown_menu' )
                            ),
                            array(
                                'id'            => 'el_class',
                                'type'          => 'text',
                                'default'       => '',
                                'title'         => esc_html_x('Extra CSS class for item', 'admin-view', 'negan')
                            )
                        ),
                        'default' => array(
                            array(
                                'type' => 'cart',
                                'link' => ''
                            )
                        )
                    ),

                    array(
                        'id'        => 'enable_header_mb_footer_bar',
                        'type'      => 'radio',
                        'default'   => 'no',
                        'class'     => 'la-radio-style',
                        'title'     => esc_html_x('Enable Mobile Footer Bar?', 'admin-view', 'negan'),
                        'options'   => array(
                            'no'            => esc_html_x('Hide', 'admin-view', 'negan'),
                            'yes'           => esc_html_x('Yes', 'admin-view', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'header_mb_footer_bar_component',
                        'type'      => 'group',
                        'wrap_class'=> 'group-disable-clone',
                        'title'     => esc_html_x('Header Mobile Footer Bar Component', 'admin-view', 'negan'),
                        'button_title'    => esc_html_x('Add Icon Component ','admin-view', 'negan'),
                        'dependency'    => array('enable_header_mb_footer_bar_yes', '==', true),
                        'accordion_title' => 'type',
                        'max_item'  => 5,
                        'fields'    => array(
                            array(
                                'id'        => 'type',
                                'type'      => 'select',
                                'title'     => esc_html_x('Type', 'admin-view', 'negan'),
                                'options'  => array(
                                    'dropdown_menu'     => esc_html_x('Dropdown Menu', 'admin-view', 'negan'),
                                    'aside'             => esc_html_x('Toggle Aside Sidebar', 'admin-view', 'negan'),
                                    'text'              => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                    'link_icon'         => esc_html_x('Icon with link', 'admin-view', 'negan'),
                                    'searchbox'          => esc_html_x('Search box style 01', 'admin-view', 'negan'),
                                    'cart'              => esc_html_x('Cart Icon', 'admin-view', 'negan'),
                                    'wishlist'          => esc_html_x('Wishlist Icon', 'admin-view', 'negan'),
                                    'compare'           => esc_html_x('Compare Icon', 'admin-view', 'negan')
                                )
                            ),
                            array(
                                'id'            => 'icon',
                                'type'          => 'icon',
                                'default'       => 'fa fa-share',
                                'title'         => esc_html_x('Custom Icon', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_icon,link_text,dropdown_menu,aside' )
                            ),
                            array(
                                'id'            => 'text',
                                'type'          => 'text',
                                'title'         => esc_html_x('Custom Text', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'text,link_text,dropdown_menu' )
                            ),
                            array(
                                'id'            => 'link',
                                'type'          => 'text',
                                'default'       => '#',
                                'title'         => esc_html_x('Link (URL)', 'admin-view', 'negan'),
                                'dependency'    => array( 'type', 'any', 'link_icon,link_text,cart,wishlist,compare' )
                            ),
                            array(
                                'id'            => 'menu_id',
                                'type'          => 'select',
                                'title'         => esc_html_x('Select the menu','admin-view', 'negan'),
                                'class'         => 'chosen',
                                'options'       => 'tags',
                                'query_args'    => array(
                                    'orderby'   => 'name',
                                    'order'     => 'ASC',
                                    'taxonomies'=>  'nav_menu',
                                    'hide_empty'=> false
                                ),
                                'dependency'    => array( 'type', '==', 'dropdown_menu' )
                            ),
                            array(
                                'id'            => 'el_class',
                                'type'          => 'text',
                                'default'       => '',
                                'title'         => esc_html_x('Extra CSS class for item', 'admin-view', 'negan')
                            )
                        ),
                        'default' => array(
                            array(
                                'type' => 'searchbox'
                            ),
                            array(
                                'type' => 'cart',
                                'link' => ''
                            )
                        )
                    ),
                    array(
                        'id'        => 'header_mobile_height',
                        'type'      => 'slider',
                        'default'    => '80px',
                        'title'     => esc_html__( 'Header Container Height', 'negan' ),
                        'options'   => array(
                            'step'    => 1,
                            'min'     => 50,
                            'max'     => 200,
                            'unit'    => 'px'
                        )
                    ),
                    array(
                        'id'        => 'header_mobile_sticky_height',
                        'type'      => 'slider',
                        'default'    => '70px',
                        'title'     => esc_html__( 'Header Sticky Container Height', 'negan' ),
                        'options'   => array(
                            'step'    => 1,
                            'min'     => 50,
                            'max'     => 200,
                            'unit'    => 'px'
                        )
                    ),
                    array(
                        'id'        => 'header_mb_background',
                        'default'   => '#fff',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Background Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Header', 'negan')
                    ),
                    array(
                        'id'        => 'header_mb_text_color',
                        'default'   => Negan_Options::get_color_default('body_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Text Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Header', 'negan')
                    ),
                    array(
                        'type'    => 'notice',
                        'class'   => 'no-format la-section-title',
                        'content' => sprintf('<h3>%s</h3>', esc_html__('Mobile Menu Styling', 'negan'))
                    ),
                    array(
                        'id'        => 'mb_background',
                        'default'   => '#fff',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Background Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_1_color',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 1 Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_1_bg_color',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 1 Background Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_1_hover_color',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 1 Hover Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_1_hover_bg_color',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 1 Hover Background Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_2_color',
                        'default'   => Negan_Options::get_color_default('secondary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 2 Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_2_bg_color',
                        'default'   => 'rgba(0,0,0,0)',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 2 Background Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_2_hover_color',
                        'default'   => '#fff',
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 2 Hover Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    ),
                    array(
                        'id'        => 'mb_lv_2_hover_bg_color',
                        'default'   => Negan_Options::get_color_default('primary_color'),
                        'type'      => 'color_picker',
                        'title'     => esc_html__('Menu Level 2 Hover Background Color', 'negan'),
                        'desc'      => esc_html__('For Mobile Menu', 'negan')
                    )
                )
            )
        )
    );
    return $sections;
}
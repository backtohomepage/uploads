<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * Social Media settings
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_options_section_social_media( $sections )
{
    $sections['social_media'] = array(
        'name'          => 'social_panel',
        'title'         => esc_html__('Social Media', 'negan'),
        'icon'          => 'fa fa fa-share-alt',
        'sections' => array(
            array(
                'name'      => 'social_link_sections',
                'title'     => esc_html__('Social Media Links', 'negan'),
                'icon'      => 'fa fa-share-alt',
                'fields'    => array(
                    array(
                        'id'        => 'social_links',
                        'type'      => 'group',
                        'title'     => esc_html__('Social Media Links', 'negan'),
                        'desc'      => esc_html__('Social media links use a repeater field and allow one network per field. Click the "Add" button to add additional fields.', 'negan'),
                        'button_title'    => esc_html__('Add','negan'),
                        'accordion_title' => 'title',
                        'fields'    => array(
                            array(
                                'id'        => 'title',
                                'type'      => 'text',
                                'default'   => esc_html__('Title', 'negan'),
                                'title'     => esc_html__('Title', 'negan')
                            ),
                            array(
                                'id'        => 'icon',
                                'type'      => 'icon',
                                'default'   => 'fa fa-share',
                                'title'     => esc_html__('Custom Icon', 'negan')
                            ),
                            array(
                                'id'        => 'link',
                                'type'      => 'text',
                                'default'   => '#',
                                'title'     => esc_html__('Link (URL)', 'negan')
                            )
                        )
                    )
                )
            ),
            array(
                'name'      => 'social_sharing_sections',
                'title'     => esc_html__('Social Sharing Box', 'negan'),
                'icon'      => 'fa fa-share-square-o',
                'fields'    => array(
                    array(
                        'id'        => 'sharing_facebook',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Facebook', 'negan'),
                        'desc'      => esc_html__('Turn on to display Facebook in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_twitter',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Twitter', 'negan'),
                        'desc'      => esc_html__('Turn on to display Twitter in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_reddit',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Reddit', 'negan'),
                        'desc'      => esc_html__('Turn on to display Reddit in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_linkedin',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('LinkedIn', 'negan'),
                        'desc'      => esc_html__('Turn on to display LinkedIn in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_google_plus',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Google+', 'negan'),
                        'desc'      => esc_html__('Turn on to display Google+ in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_tumblr',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Tumblr', 'negan'),
                        'desc'      => esc_html__('Turn on to display Tumblr in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_pinterest',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Pinterest', 'negan'),
                        'desc'      => esc_html__('Turn on to display Pinterest in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_vk',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('VK', 'negan'),
                        'desc'      => esc_html__('Turn on to display VK in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_email',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Email', 'negan'),
                        'desc'      => esc_html__('Turn on to display Email in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_whatapps',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Whatsapp', 'negan'),
                        'desc'      => esc_html__('Turn on to display Whatsapp in the social share box.', 'negan')
                    ),
                    array(
                        'id'        => 'sharing_telegram',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Telegram', 'negan'),
                        'desc'      => esc_html__('Turn on to display Telegram in the social share box.', 'negan')
                    )
                )
            )
        )
    );
    return $sections;
}
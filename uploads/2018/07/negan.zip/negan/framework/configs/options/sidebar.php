<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * Sidebar settings
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_options_section_sidebar( $sections )
{
    $sections['sidebar'] = array(
        'name'          => 'sidebar_panel',
        'title'         => esc_html__('Sidebars', 'negan'),
        'icon'          => 'fa fa-exchange',
        'sections' => array(
            array(
                'name'      => 'sidebar_add_section',
                'title'     => esc_html__('Add Sidebar', 'negan'),
                'icon'      => 'fa fa-plus',
                'fields'    => array(
                    array(
                        'id'        => 'add_sidebars',
                        'type'      => 'group',
                        'title'     => esc_html__('Add New Sidebar', 'negan'),
                        'button_title'    => esc_html__('Add','negan'),
                        'accordion_title' => 'sidebar_id',
                        'fields'    => array(
                            array(
                                'id'        => 'sidebar_id',
                                'type'      => 'text',
                                'default'   => esc_html__('Sidebar ID', 'negan'),
                                'title'     => esc_html__('Title', 'negan')
                            ),
                            array(
                                'id'        => 'sidebar_desc',
                                'type'      => 'text',
                                'title'     => esc_html__('Description', 'negan')
                            )
                        )
                    )
                )
            ),
            array(
                'name'      => 'sidebar_page_panel',
                'title'     => esc_html__('Pages', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'pages_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global Page Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all pages.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'pages_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For Pages', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all pages. This option overrides the page options.', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_portfolio_posts_panel',
                'title'     => esc_html__('Portfolio Posts', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'portfolio_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global Portfolio Post Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all portfolio posts.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'portfolio_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For Portfolio Posts', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all portfolio posts. This option overrides the portfolio post options.', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_portfolio_archive_panel',
                'title'     => esc_html__('Portfolio Archive', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'portfolio_archive_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global Portfolio Archive Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all portfolio archive & taxonomy.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'portfolio_archive_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For Portfolio Archive', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all portfolio archive & taxonomy. This option overrides the portfolio options.', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_posts_panel',
                'title'     => esc_html__('Blog Posts', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'posts_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global Blog Post Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all blog posts.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'posts_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For Blog Posts', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all blog posts. This option overrides the blog post options.', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_blog_post_panel',
                'title'     => esc_html__('Blog Archive', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'blog_archive_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global Blog Archive Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all post category & tag.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'blog_archive_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For Blog Archive', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all post category & tag. This option overrides the posts options.', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_search_panel',
                'title'     => esc_html__('Search Page', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'search_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Search Page Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on the search results page.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_products_panel',
                'title'     => esc_html__('Woocommerce Products', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'products_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global WooCommerce Product Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all WooCommerce products.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'products_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For WooCommerce Products', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all WooCommerce products. This option overrides the WooCommerce post options.', 'negan')
                    )
                )
            ),
            array(
                'name'      => 'sidebar_shop_panel',
                'title'     => esc_html__('Woocommerce Archive', 'negan'),
                'fields'    => array(
                    array(
                        'id'             => 'shop_sidebar',
                        'type'           => 'select',
                        'title'          => esc_html__('Global WooCommerce Archive Sidebar', 'negan'),
                        'desc'           => esc_html__('Select sidebar that will display on all WooCommerce taxonomy.', 'negan'),
                        'class'          => 'chosen',
                        'options'        => 'sidebars',
                        'default_option' => esc_html__('None', 'negan')
                    ),
                    array(
                        'id'        => 'shop_global_sidebar',
                        'type'      => 'switcher',
                        'default'   => false,
                        'title'     => esc_html__('Activate Global Sidebar For Woocommerce Archive', 'negan'),
                        'desc'      => esc_html__('Turn on if you want to use the same sidebars on all WooCommerce archive( shop,category,tag,search ). This option overrides the WooCommerce taxonomy options.', 'negan')
                    )
                )
            )
        )
    );
    return $sections;
}
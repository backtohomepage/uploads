<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * WooCommerce settings
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_options_section_woocommerce( $sections )
{
    $sections['woocommerce'] = array(
        'name' => 'woocommerce_panel',
        'title' => esc_html__('WooCommerce', 'negan'),
        'title2' => esc_html__('Shop', 'negan'),
        'icon' => 'fa fa-shopping-cart',
        'sections' => array(
            array(
                'name'      => 'woocommerce_general_section',
                'title'     => esc_html__('General WooCommerce', 'negan'),
                'icon'      => 'fa fa-check',
                'fields'    => array(
                    array(
                        'id'        => 'layout_archive_product',
                        'type'      => 'image_select',
                        'title'     => esc_html__('WooCommerce Layout', 'negan'),
                        'desc'      => esc_html__('Controls the layout of shop page, product category, product tags and search page', 'negan'),
                        'default'   => 'col-1c',
                        'radio'     => true,
                        'options'   => Negan_Options::get_config_main_layout_opts(true, false)
                    ),
                    array(
                        'id'        => 'catalog_mode',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('Catalog Mode', 'negan'),
                        'desc'      => esc_html__('Turn on to disable the shopping functionality of WooCommerce.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'catalog_mode_price',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('Catalog Mode Price', 'negan'),
                        'desc'      => esc_html__('Turn on to do not show product price', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false),
                        'dependency' => array('catalog_mode_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'active_shop_filter',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('Advanced WooCommerce Filter', 'negan'),
                        'desc'      => esc_html__('Turn off/on advance shop filter', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'hide_shop_toolbar',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('Hide WooCommerce Toolbar', 'negan'),
                        'desc'      => esc_html__('Turn off/on WooCommerce Toolbar', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'shop_catalog_display_type',
                        'default'   => 'grid',
                        'title'     => esc_html__('Shop display as type', 'negan'),
                        'desc'      => esc_html__('Controls the type display of product for the shop page', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            'grid'        => esc_html__('Grid', 'negan'),
                            'list'        => esc_html__('List', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'shop_catalog_grid_style',
                        'default'   => '1',
                        'title'     => esc_html__('Grid Style', 'negan'),
                        'desc'      => esc_html__('Controls the type display of product for the shop page', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            '1'        => esc_html__('Style 01', 'negan'),
                            '2'        => esc_html__('Style 02', 'negan'),
                            '3'        => esc_html__('Style 03', 'negan'),
                            '4'        => esc_html__('Style 04', 'negan'),
                            '5-2'      => esc_html__('Style 05', 'negan'),
                            '6'        => esc_html__('Style 06', 'negan'),
                            '7'        => esc_html__('Style 07', 'negan')
                        )
                    ),
                    array(
                        'id'        => 'active_shop_masonry',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('Enable Shop Masonry', 'negan'),
                        'desc'      => esc_html__('Turn off/on Shop Masonry Mode', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),

                    array(
                        'id'        => 'shop_masonry_column_type',
                        'default'   => '1',
                        'title'     => esc_html__('Masonry Column Type', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            'default'        => esc_html__('Default', 'negan'),
                            'custom'         => esc_html__('Custom', 'negan')
                        ),
                        'dependency' => array('active_shop_masonry_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'product_masonry_image_size',
                        'default'   => 'shop_catalog',
                        'title'     => esc_html__('Masonry Product Image Size', 'negan'),
                        'info'      => esc_html__('Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'negan'),
                        'type'      => 'text',
                        'dependency' => array('shop_masonry_column_type', '==', 'custom')
                    ),
                    array(
                        'id'        => 'product_masonry_item_width',
                        'default'   => '270',
                        'title'     => esc_html__('Set your product item default width', 'negan'),
                        'info'      => esc_html__('Enter numeric only', 'negan'),
                        'type'      => 'text',
                        'dependency' => array('shop_masonry_column_type', '==', 'custom')
                    ),
                    array(
                        'id'        => 'product_masonry_item_height',
                        'default'   => '450',
                        'title'     => esc_html__('Set your product item default height', 'negan'),
                        'info'      => esc_html__('Enter numeric only', 'negan'),
                        'type'      => 'text',
                        'dependency' => array('shop_masonry_column_type', '==', 'custom')
                    ),

                    array(
                        'id'        => 'woocommerce_shop_page_columns',
                        'default'   => array(
                            'xlg' => 4,
                            'lg' => 4,
                            'md' => 3,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        ),
                        'title'     => esc_html__('WooCommerce Number of Product Columns', 'negan'),
                        'desc'      => esc_html__('Controls the number of columns for the main shop page', 'negan'),
                        'type'      => 'column_responsive',
                        'dependency' => array('active_shop_masonry_off', '==', 'true')
                    ),

                    array(
                        'id'        => 'woocommerce_shop_masonry_columns',
                        'default'   => array(
                            'xlg' => 4,
                            'lg' => 4,
                            'md' => 3,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        ),
                        'title'     => esc_html__('WooCommerce Number of Product Columns', 'negan'),
                        'desc'      => esc_html__('Controls the number of columns for the main shop page', 'negan'),
                        'type'      => 'column_responsive',
                        'dependency' => array('active_shop_masonry_on|shop_masonry_column_type', '==|==', 'true|default')
                    ),

                    array(
                        'id'        => 'woocommerce_shop_masonry_custom_columns',
                        'default'   => array(
                            'md' => 3,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        ),
                        'options'   => array(
                            'xlg' => false,
                            'lg' => false
                        ),
                        'title'     => esc_html__('WooCommerce Number of Product Columns', 'negan'),
                        'desc'      => esc_html__('Controls the number of columns for the main shop page', 'negan'),
                        'type'      => 'column_responsive',
                        'dependency' => array('active_shop_masonry_on|shop_masonry_column_type', '==|==', 'true|custom')
                    ),

                    array(
                        'id'        => 'shop_masonry_item_gap',
                        'default'   => '30',
                        'title'     => esc_html__('Masonry Column Space', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            '0'         => esc_html__('0px', 'negan'),
                            '10'        => esc_html__('10px', 'negan'),
                            '15'        => esc_html__('15px', 'negan'),
                            '20'        => esc_html__('20px', 'negan'),
                            '25'        => esc_html__('25px', 'negan'),
                            '30'        => esc_html__('30px', 'negan'),
                        ),
                        'dependency' => array('active_shop_masonry_on', '==', 'true')
                    ),

                    array(
                        'id'        => 'enable_shop_masonry_custom_setting',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('Enable Custom Item Settings', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false),
                        'dependency' => array('active_shop_masonry_on|shop_masonry_column_type', '==|==', 'true|custom')
                    ),
                    array(
                        'id'        => 'shop_masonry_item_setting',
                        'type'      => 'group',
                        'title'     => esc_html__('Add Item Sizes', 'negan'),
                        'button_title'    => esc_html__('Add','negan'),
                        'accordion_title' => 'size_name',
                        'default'   => array(
                            array(
                                'size_name' => esc_html__('1x Width + 1x Height', 'negan'),
                                'width' => 1,
                                'height' => 1
                            )
                        ),
                        'fields'    => array(
                            array(
                                'id'        => 'size_name',
                                'type'      => 'text',
                                'default'   => esc_html__('1x Width + 1x Height', 'negan'),
                                'title'     => esc_html__('Size Name', 'negan')
                            ),
                            array(
                                'id'        => 'width',
                                'default'   => '1',
                                'title'     => esc_html__('Width', 'negan'),
                                'info'      => esc_html__('it will occupy x width of base item width ( example: this item will be occupy 2x width of base width you need entered "2")', 'negan'),
                                'type'      => 'select',
                                'options'   => array(
                                    '0.5'      => esc_html__('0.5x width', 'negan'),
                                    '1'        => esc_html__('1x width', 'negan'),
                                    '1.5'      => esc_html__('1.5x width', 'negan'),
                                    '2'        => esc_html__('2x width', 'negan'),
                                    '2.5'      => esc_html__('2.5x width', 'negan'),
                                    '3'        => esc_html__('3x width', 'negan'),
                                    '3.5'      => esc_html__('3.5x width', 'negan'),
                                    '4'        => esc_html__('4x width', 'negan')
                                )
                            ),
                            array(
                                'id'        => 'height',
                                'default'   => '1',
                                'title'     => esc_html__('Height', 'negan'),
                                'info'      => esc_html__('it will occupy x height of base item height ( example: this item will be occupy 2x height of base height you need entered "2")', 'negan'),
                                'type'      => 'select',
                                'options'   => array(
                                    '0.5'      => esc_html__('0.5x height', 'negan'),
                                    '1'        => esc_html__('1x height', 'negan'),
                                    '1.5'      => esc_html__('1.5x height', 'negan'),
                                    '2'        => esc_html__('2x height', 'negan'),
                                    '2.5'      => esc_html__('2.5x height', 'negan'),
                                    '3'        => esc_html__('3x height', 'negan'),
                                    '3.5'      => esc_html__('3.5x height', 'negan'),
                                    '4'        => esc_html__('4x height', 'negan')
                                )
                            )
                        ),
                        'dependency' => array('active_shop_masonry_on|shop_masonry_column_type|enable_shop_masonry_custom_setting_on', '==|==|==', 'true|custom|true')
                    ),
                    array(
                        'id'        => 'product_per_page_allow',
                        'default'   => '12,15,30',
                        'title'     => esc_html__('WooCommerce Number of Products per Page Allow', 'negan'),
                        'desc'      => esc_html__('Controls the number of products that display per page.', 'negan'),
                        'info'      => esc_html__('Comma-separated. ( i.e: 3,6,9)', 'negan'),
                        'type'      => 'text'
                    ),
                    array(
                        'id'        => 'product_per_page_default',
                        'default'   => 12,
                        'title'     => esc_html__('WooCommerce Number of Products per Page', 'negan'),
                        'desc'      => esc_html__('The value of field must be as one value of setting above', 'negan'),
                        'type'      => 'number',
                        'attributes'=> array(
                            'min' => 1,
                            'max' => 100
                        )
                    ),
                    array(
                        'id'        => 'woocommerce_enable_crossfade_effect',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('WooCommerce Crossfade Image Effect', 'negan'),
                        'desc'      => esc_html__('Turn on to display the product crossfade image effect on the product.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'woocommerce_toggle_grid_list',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'on',
                        'title'     => esc_html__('WooCommerce Product Grid / List View', 'negan'),
                        'desc'      => esc_html__('Turn on to display the grid/list toggle on the main shop page and archive shop pages.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'woocommerce_show_rating_on_catalog',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('WooCommerce Show Ratings', 'negan'),
                        'desc'      => esc_html__('Turn on to display the ratings on the main shop page and archive shop pages.', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'woocommerce_show_quickview_btn',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('WooCommerce Show Quick View Button', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'woocommerce_show_wishlist_btn',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('WooCommerce Show Wishlist Button', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'woocommerce_show_compare_btn',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'off',
                        'title'     => esc_html__('WooCommerce Show Compare Button', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    )
                )
            ),
            array(
                'name'      => 'woocommerce_single_section',
                'title'     => esc_html__('Product Page Settings', 'negan'),
                'icon'      => 'fa fa-check',
                'fields'    => array(
                    array(
                        'id'        => 'layout_single_product',
                        'type'      => 'image_select',
                        'radio'     => true,
                        'title'     => esc_html__('Product Page Layout', 'negan'),
                        'desc'      => esc_html__('Controls the layout for detail product page', 'negan'),
                        'default'   => 'col-1c',
                        'options'   => Negan_Options::get_config_main_layout_opts(true, false)
                    ),
                    array(
                        'id'        => 'woocommerce_product_page_design',
                        'default'   => '1',
                        'title'     => esc_html__('Product Page Design', 'negan'),
                        'type'      => 'select',
                        'options'   => array(
                            '1'        => esc_html__('Design 01', 'negan'),
                            '2'        => esc_html__('Design 02', 'negan'),
                            '3'        => esc_html__('Design 03', 'negan'),
                            '4'        => esc_html__('Design 04', 'negan'),
                            '5'        => esc_html__('Design 05', 'negan'),
                        )
                    ),
                    array(
                        'id'        => 'single_ajax_add_cart',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'no',
                        'title'     => esc_html_x('Ajax Add to Cart', 'admin-view', 'negan'),
                        'desc'      => esc_html_x('Support Ajax Add to cart for all types of products', 'admin-view', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'woocommerce_gallery_zoom',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'yes',
                        'title'     => esc_html_x('Enable WooCommerce Zoom', 'admin-view', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'woocommerce_gallery_lightbox',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'yes',
                        'title'     => esc_html_x('Enable WooCommerce LightBox', 'admin-view', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'product_single_hide_breadcrumb',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'no',
                        'title'     => esc_html__('Hide Breadcrumbs', 'negan'),
                        'desc'      => esc_html__('In Page Title Bar', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'product_single_hide_page_title',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'no',
                        'title'     => esc_html__('Hide Page Title', 'negan'),
                        'desc'      => esc_html__('In Page Title Bar', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'product_single_hide_product_title',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'no',
                        'title'     => esc_html__('Hide Product Title', 'negan'),
                        'options'   => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'product_gallery_column',
                        'title'     => esc_html_x('Product gallery columns', 'admin-view', 'negan'),
                        'default'   => array(
                            'xlg' => 3,
                            'lg' => 3,
                            'md' => 3,
                            'sm' => 5,
                            'xs' => 4,
                            'mb' => 3
                        ),
                        'type'      => 'column_responsive',
                    ),

                    array(
                        'id'        => 'product_sharing',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'on',
                        'title'     => esc_html__('Product Sharing Option', 'negan'),
                        'desc'      => esc_html__('Turn on to show social sharing on the product page', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'related_products',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'on',
                        'title'     => esc_html__('WooCommerce Related Products', 'negan'),
                        'desc'      => esc_html__('Turn on to show related products on the product page', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'related_product_title',
                        'type'      => 'text',
                        'title'     => esc_html__('WooCommerce Related Title','negan'),
                        'dependency'=> array('related_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'related_product_subtitle',
                        'type'      => 'text',
                        'title'     => esc_html__('WooCommerce Related Sub Title','negan'),
                        'dependency'=> array('related_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'related_products_columns',
                        'default'   => array(
                            'xlg' => 4,
                            'lg' => 4,
                            'md' => 3,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        ),
                        'title'     => esc_html__('WooCommerce Related Product Number of Columns', 'negan'),
                        'desc'      => esc_html__('Controls the number of columns for the related', 'negan'),
                        'type'      => 'column_responsive',
                        'dependency' => array('related_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'upsell_products',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'on',
                        'title'     => esc_html__('WooCommerce Up-sells Products', 'negan'),
                        'desc'      => esc_html__('Turn on to show Up-sells products on the product page', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'upsell_product_title',
                        'type'      => 'text',
                        'title'     => esc_html__('WooCommerce Up-sells Title','negan'),
                        'dependency'=> array('upsell_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'upsell_product_subtitle',
                        'type'      => 'text',
                        'title'     => esc_html__('WooCommerce Up-sells Sub Title','negan'),
                        'dependency'=> array('upsell_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'upsell_products_columns',
                        'default'   => array(
                            'xlg' => 4,
                            'lg' => 4,
                            'md' => 3,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        ),
                        'title'     => esc_html__('WooCommerce Up-sells Product Number of Columns', 'negan'),
                        'desc'      => esc_html__('Controls the number of columns for the Up-sells', 'negan'),
                        'type'      => 'column_responsive',
                        'dependency' => array('upsell_products_on', '==', 'true')
                    ),
                )
            ),
            array(
                'name'      => 'woocommerce_cart_section',
                'title'     => esc_html__('Cart Page Settings', 'negan'),
                'icon'      => 'fa fa-shopping-cart',
                'fields'    => array(
                    array(
                        'id'        => 'crosssell_products',
                        'type'      => 'radio',
                        'class'     => 'la-radio-style',
                        'default'   => 'on',
                        'title'     => esc_html__('WooCommerce Cross-sells Products', 'negan'),
                        'desc'      => esc_html__('Turn on to show Cross-sells products on the product page', 'negan'),
                        'options'   => Negan_Options::get_config_radio_onoff(false)
                    ),
                    array(
                        'id'        => 'crosssell_product_title',
                        'type'      => 'text',
                        'title'     => esc_html__('WooCommerce Cross-sells Title','negan'),
                        'dependency'=> array('crosssell_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'crosssell_product_subtitle',
                        'type'      => 'text',
                        'title'     => esc_html__('WooCommerce Cross-sells Sub Title','negan'),
                        'dependency'=> array('crosssell_products_on', '==', 'true')
                    ),
                    array(
                        'id'        => 'crosssell_products_columns',
                        'default'   => array(
                            'xlg' => 4,
                            'lg' => 4,
                            'md' => 3,
                            'sm' => 2,
                            'xs' => 1,
                            'mb' => 1
                        ),
                        'title'     => esc_html__('WooCommerce Cross-sells Product Number of Columns', 'negan'),
                        'desc'      => esc_html__('Controls the number of columns for the Cross-sells', 'negan'),
                        'type'      => 'column_responsive',
                        'dependency' => array('crosssell_products_on', '==', 'true')
                    )
                )
            )
        )
    );
    return $sections;
}
<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * MetaBox
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_metaboxes_section_member( $sections )
{
    $sections['member'] = array(
        'name'      => 'member',
        'title'     => esc_html__('Member Information', 'negan'),
        'icon'      => 'laicon-file',
        'fields'    => array(
            array(
                'id'    => 'role',
                'type'  => 'text',
                'title' => esc_html__('Role', 'negan'),
            ),
            array(
                'id'    => 'phone',
                'type'  => 'text',
                'title' => esc_html__('Phone Number', 'negan'),
            ),
            array(
                'id'    => 'facebook',
                'type'  => 'text',
                'title' => esc_html__('Facebook URL', 'negan'),
            ),
            array(
                'id'    => 'twitter',
                'type'  => 'text',
                'title' => esc_html__('Twitter URL', 'negan'),
            ),
            array(
                'id'    => 'pinterest',
                'type'  => 'text',
                'title' => esc_html__('Pinterest URL', 'negan'),
            ),
            array(
                'id'    => 'linkedin',
                'type'  => 'text',
                'title' => esc_html__('LinkedIn URL', 'negan'),
            ),
            array(
                'id'    => 'dribbble',
                'type'  => 'text',
                'title' => esc_html__('Dribbble URL', 'negan'),
            ),
            array(
                'id'    => 'google_plus',
                'type'  => 'text',
                'title' => esc_html__('Google Plus URL', 'negan'),
            ),
            array(
                'id'    => 'youtube',
                'type'  => 'text',
                'title' => esc_html__('Youtube URL', 'negan'),
            ),
            array(
                'id'    => 'email',
                'type'  => 'text',
                'title' => esc_html__('Email Address', 'negan'),
            )
        )
    );
    return $sections;
}
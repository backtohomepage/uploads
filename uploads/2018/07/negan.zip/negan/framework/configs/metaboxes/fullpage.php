<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * MetaBox
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_metaboxes_section_fullpage( $sections )
{
    $sections['fullpage'] = array(
        'name'      => 'fullpage',
        'title'     => esc_html__('One Page JS', 'negan'),
        'icon'      => 'laicon-anchor',
        'fields'    => array(
            array(
                'id'            => 'enable_fp',
                'type'          => 'radio',
                'default'       => 'no',
                'class'         => 'la-radio-style la_enable_fp_fields',
                'title'         => esc_html__('Enable One Page', 'negan'),
                'desc'          => esc_html__('This option just apply for page layout 1 column', 'negan'),
                'options'       => Negan_Options::get_config_radio_opts(false)
            ),
            array(
                'id'            => 'fp_section_nav',
                'type'          => 'fieldset',
                'title'         => esc_html__('Navigation', 'negan'),
                'dependency'    => array( 'enable_fp_yes', '==', 'true' ),
                'wrap_class'    => 'la-fieldset-toggle',
                'un_array'      => true,
                'fields'        => array(
                    array(
                        'id'            => 'fp_navigation',
                        'type'          => 'select',
                        'title'         => esc_html__('Section Navigation', 'negan'),
                        'desc'          => esc_html__('This parameter determines the position of navigation bar.', 'negan'),
                        'default'       => 'off',
                        'options'       => array(
                            'off' => esc_html__('Off', 'negan'),
                            'left' => esc_html__('Left', 'negan'),
                            'right' => esc_html__('Right', 'negan')
                        )
                    ),
                    array(
                        'id'            => 'fp_sectionnavigationstyle',
                        'type'          => 'select',
                        'title'         => esc_html__('Section Navigation Style', 'negan'),
                        'desc'          => esc_html__('This parameter determines section navigation style.', 'negan'),
                        'default'       => 'default',
                        'options'       => array(
                            '1'               => esc_html__('Style 01', 'negan'),
                            '2'               => esc_html__('Style 02', 'negan')
                        ),
                        'dependency'    => array( 'fp_navigation', '!=', 'off' )
                    ),
                    /*
                    array(
                        'id'            => 'fp_showactivetooltip',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Show Active Tooltip', 'negan'),
                        'desc'          => esc_html__('This parameter shows a persistent tooltip for the actively viewed section in the vertical navigation.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_navigation', '!=', 'off' )
                    ),
                    array(
                        'id'            => 'fp_bigsectionnavigation',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Bigger Navigation', 'negan'),
                        'desc'          => esc_html__('This parameter sets bigger navigation bullets.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_navigation', '!=', 'off' )
                    ),
                    */
                    array(
                        'id'            => 'fp_slidenavigation',
                        'type'          => 'select',
                        'title'         => esc_html__('Slides Navigation', 'negan'),
                        'desc'          => esc_html__('This parameter determines the position of landscape navigation bar for sliders.', 'negan'),
                        'default'       => 'off',
                        'options'       => array(
                            'off'   => esc_html__('Off', 'negan'),
                            'left'  => esc_html__('Top', 'negan'),
                            'bottom'   => esc_html__('Bottom', 'negan')
                        )
                    ),
                    array(
                        'id'            => 'fp_slidenavigationstyle',
                        'type'          => 'select',
                        'title'         => esc_html__('Slide Navigation Style', 'negan'),
                        'desc'          => esc_html__('This parameter determines section navigation style.', 'negan'),
                        'default'       => 'default',
                        'options'       => array(
                            '1'               => esc_html__('Style 01', 'negan'),
                            '2'               => esc_html__('Style 02', 'negan')
                        ),
                        'dependency'    => array( 'fp_slidenavigation', '!=', 'off' )
                    ),
                    /*
                    array(
                        'id'            => 'fp_bigslidenavigation',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Bigger Slide Navigation', 'negan'),
                        'desc'          => esc_html__('This parameter sets bigger slide navigation bullets .', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_slidenavigation', '!=', 'off' )
                    ),
                    array(
                        'id'            => 'fp_controlarrows',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Control Arrows', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether to use control arrows for the slides to move right or left.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    */
                    array(
                        'id'            => 'fp_lockanchors',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Lock Anchors', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether anchors in the URL will have any effect.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_animateanchor',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Animate Anchor', 'negan'),
                        'desc'          => esc_html__('This parameter defines whether the load of the site when given anchor (#) will scroll with animation to its destination.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_keyboardscrolling',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Keyboard Scrolling', 'negan'),
                        'desc'          => esc_html__('This parameter defines if the content can be navigated using the keyboard.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_recordhistory',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Record History', 'negan'),
                        'desc'          => esc_html__('This parameter defines whether to push the state of the site to the browsers history, so back button will work on section navigation.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    )
                ),
            ),
            array(
                'id'            => 'fp_section_scroll',
                'type'          => 'fieldset',
                'title'         => esc_html__('Scrolling', 'negan'),
                'dependency'    => array( 'enable_fp_yes', '==', 'true' ),
                'wrap_class'    => 'la-fieldset-toggle',
                'un_array'      => true,
                'fields'        => array(
                    array(
                        'id'            => 'fp_autoscrolling',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Auto Scrolling', 'negan'),
                        'desc'          => esc_html__('This parameter defines whether to use the automatic scrolling or the normal one.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_fittosection',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Fit To Section', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether or not to fit sections to the viewport or not.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_fittosectiondelay',
                        'type'          => 'number',
                        'default'       => 1000,
                        'title'         => esc_html__('Fit To Section Delay', 'negan'),
                        'desc'          => esc_html__('The delay in miliseconds for section fitting.', 'negan'),
                        'dependency'    => array( 'fp_fittosection_yes', '==', 'true' )
                    ),
                    array(
                        'id'            => 'fp_scrollbar',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Scroll Bar', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether to use the scrollbar for the site or not.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_scrolloverflow',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Scroll Overflow', 'negan'),
                        'desc'          => esc_html__('This parameter defines whether or not to create a scroll for the section in case the content is bigger than the height of it.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_hidescrollbars',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Hide Scrollbars', 'negan'),
                        'desc'          => esc_html__('This parameter hides scrollbar even if the scrolling is enabled inside the sections.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_scrolloverflow_yes', '==', 'true' )
                    ),
                    array(
                        'id'            => 'fp_fadescrollbars',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Fade Scrollbars', 'negan'),
                        'desc'          => esc_html__('This parameter fades scrollbar when unused.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_scrolloverflow_yes', '==', 'true' )
                    ),
                    array(
                        'id'            => 'fp_interactivescrollbars',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Interactive Scrollbars', 'negan'),
                        'desc'          => esc_html__('This parameter makes scrollbar draggable and user can interact with it.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_scrolloverflow_yes', '==', 'true' )
                    ),
                    array(
                        'id'            => 'fp_bigsectionsdestination',
                        'type'          => 'select',
                        'title'         => esc_html__('Big Sections Destination', 'negan'),
                        'desc'          => esc_html__('This parameter defines how to scroll to a section which size is bigger than the viewport.', 'negan'),
                        'default'       => 'default',
                        'options'       => array(
                            'default'   => esc_html__('Default', 'negan'),
                            'top'       => esc_html__('Top', 'negan'),
                            'bottom'    => esc_html__('Bottom', 'negan')
                        )
                    ),
                    array(
                        'id'            => 'fp_contvertical',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Continuous Vertical', 'negan'),
                        'desc'          => esc_html__('This parameter determines vertical scrolling is continuous.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_loopbottom',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Loop Bottom', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether to use the scrollbar for the site or not.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_contvertical_no', '==', 'true' )
                    ),
                    array(
                        'id'            => 'fp_looptop',
                        'type'          => 'radio',
                        'default'       => 'no',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Loop Top', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether to use the scrollbar for the site or not.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false),
                        'dependency'    => array( 'fp_contvertical_no', '==', 'true' )
                    ),
                    array(
                        'id'            => 'fp_loophorizontal',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Loop Slides', 'negan'),
                        'desc'          => esc_html__('This parameter defines whether horizontal sliders will loop after reaching the last or previous slide or not.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'            => 'fp_easing',
                        'type'          => 'select',
                        'title'         => esc_html__('Easing', 'negan'),
                        'desc'          => esc_html__('This parameter determines the transition effect.', 'negan'),
                        'default'       => 'css3_ease',
                        'options'       => array(
                            'css3_ease'             => esc_html__('CSS3 - Ease', 'negan'),
                            'css3_linear'           => esc_html__('CSS3 - Linear', 'negan'),
                            'css3_ease-in'          => esc_html__('CSS3 - Ease In', 'negan'),
                            'css3_ease-out'         => esc_html__('CSS3 - Ease Out', 'negan'),
                            'css3_ease-in-out'      => esc_html__('CSS3 - Ease In Out', 'negan'),
                            'js_linear'             => esc_html__('Linear', 'negan'),
                            'js_swing'              => esc_html__('Swing', 'negan'),
                            'js_easeInQuad'         => esc_html__('Ease In Quad', 'negan'),
                            'js_easeOutQuad'        => esc_html__('Ease Out Quad', 'negan'),
                            'js_easeInOutQuad'      => esc_html__('Ease In Out Quad', 'negan'),
                            'js_easeInCubic'        => esc_html__('Ease In Cubic', 'negan'),
                            'js_easeOutCubic'       => esc_html__('Ease Out Cubic', 'negan'),
                            'js_easeInOutCubic'     => esc_html__('Ease In Out Cubic', 'negan'),
                            'js_easeInQuart'        => esc_html__('Ease In Quart', 'negan'),
                            'js_easeOutQuart'       => esc_html__('Ease Out Quart', 'negan'),
                            'js_easeInOutQuart'     => esc_html__('Ease In Out Quart', 'negan'),
                            'js_easeInQuint'        => esc_html__('Ease In Quint', 'negan'),
                            'js_easeOutQuint'       => esc_html__('Ease Out Quint', 'negan'),
                            'js_easeInOutQuint'     => esc_html__('Ease In Out Quint', 'negan'),
                            'js_easeInExpo'         => esc_html__('Ease In Expo', 'negan'),
                            'js_easeOutExpo'        => esc_html__('Ease Out Expo', 'negan'),
                            'js_easeInOutExpo'      => esc_html__('Ease In Out Expo', 'negan'),
                            'js_easeInSine'         => esc_html__('Ease In Sine', 'negan'),
                            'js_easeOutSine'        => esc_html__('Ease Out Sine', 'negan'),
                            'js_easeInOutSine'      => esc_html__('Ease In Out Sine', 'negan'),
                            'js_easeInCirc'         => esc_html__('Ease In Circ', 'negan'),
                            'js_easeOutCirc'        => esc_html__('Ease Out Circ', 'negan'),
                            'js_easeInOutCirc'      => esc_html__('Ease In Out Circ', 'negan'),
                            'js_easeInElastic'      => esc_html__('Ease In Elastic', 'negan'),
                            'js_easeOutElastic'     => esc_html__('Ease Out Elastic', 'negan'),
                            'js_easeInOutElastic'   => esc_html__('Ease In Out Elastic', 'negan'),
                            'js_easeInBack'         => esc_html__('Ease In Back', 'negan'),
                            'js_easeOutBack'        => esc_html__('Ease Out Back', 'negan'),
                            'js_easeInOutBack'      => esc_html__('Ease In Out Back', 'negan'),
                            'js_easeInBounce'       => esc_html__('Ease In Bounce', 'negan'),
                            'js_easeOutBounce'      => esc_html__('Ease Out Bounce', 'negan'),
                            'js_easeInOutBounce'    => esc_html__('Ease In Out Bounce', 'negan')
                        )
                    ),
                    array(
                        'id'            => 'fp_scrollingspeed',
                        'type'          => 'number',
                        'default'       => 700,
                        'title'         => esc_html__('Scrolling Speed', 'negan'),
                        'desc'          => esc_html__('Speed in miliseconds for the scrolling transitions.', 'negan')
                    )
                )
            ),
            array(
                'id'            => 'fp_section_design',
                'type'          => 'fieldset',
                'title'         => esc_html__('Design', 'negan'),
                'dependency'    => array( 'enable_fp_yes', '==', 'true' ),
                'wrap_class'    => 'la-fieldset-toggle',
                'un_array'      => true,
                'fields'        => array(
                    array(
                        'id'            => 'fp_section_effect',
                        'type'          => 'select',
                        'title'         => esc_html_x('Scrolling Sections Effect', 'admin-view', 'negan'),
                        'default'       => 'default',
                        'options'       => array(
                            'default'       => esc_html_x('Default', 'admin-view', 'negan'),
                            'style-1'       => esc_html_x('Style 01', 'admin-view', 'negan'),
                        )
                    ),
                    array(
                        'id'            => 'fp_verticalcentered',
                        'type'          => 'radio',
                        'default'       => 'yes',
                        'class'         => 'la-radio-style',
                        'title'         => esc_html__('Vertically Centered', 'negan'),
                        'desc'          => esc_html__('This parameter determines whether to center the content vertically.', 'negan'),
                        'options'       => Negan_Options::get_config_radio_opts(false)
                    ),
                    array(
                        'id'        => 'fp_respwidth',
                        'type'      => 'slider',
                        'default'   => 0,
                        'title'     => esc_html__('Responsive Width', 'negan' ),
                        'desc'      => esc_html__('Normal scroll will be used under the defined width in pixels. (autoScrolling: false)', 'negan'),
                        'options'   => array(
                            'step'    => 1,
                            'min'     => 0,
                            'max'     => 1920,
                            'unit'    => 'px'
                        )
                    ),
                    array(
                        'id'        => 'fp_respheight',
                        'type'      => 'slider',
                        'default'   => 0,
                        'title'     => esc_html__('Responsive Height	', 'negan' ),
                        'desc'      => esc_html__('Normal scroll will be used under the defined height in pixels. (autoScrolling: false)', 'negan'),
                        'options'   => array(
                            'step'    => 1,
                            'min'     => 0,
                            'max'     => 5000,
                            'unit'    => 'px'
                        )
                    ),
                    array(
                        'id'        => 'fp_padding',
                        'type'      => 'spacing',
                        'title'     => esc_html__('Padding', 'negan'),
                        'desc'      => esc_html__('Defines top/bottom padding for each section. Useful in case of using fixed header/footer', 'negan'),
                        'unit' 	    => 'px',
                        'default'   => array(
                            'top' => 0,
                            'bottom' => 0
                        )
                    )
                )
            )
        )
    );
    return $sections;
}
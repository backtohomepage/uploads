<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


/**
 * MetaBox
 *
 * @param array $sections An array of our sections.
 * @return array
 */
function negan_metaboxes_section_portfolio( $sections )
{
    $sections['portfolio'] = array(
        'name'      => 'portfolio',
        'title'     => esc_html__('Portfolio', 'negan'),
        'icon'      => 'laicon-file',
        'fields'    => array(
            array(
                'id'        => 'short_description',
                'type'      => 'textarea',
                'title'     => esc_html__('Short Description', 'negan')
            ),
            array(
                'id'        => 'portfolio_design',
                'type'      => 'select',
                'title'     => esc_html__('Portfolio Single Design', 'negan'),
                'options'    => array(
                    'inherit' => esc_html__('Inherit', 'negan'),
                    '1' => esc_html__('Design 01', 'negan'),
                    '2' => esc_html__('Design 02', 'negan'),
                    'use_vc' => esc_html__('Show only post content', 'negan')
                )
            ),
            array(
                'id'        => 'gallery',
                'type'      => 'gallery',
                'title'     => esc_html__('Gallery', 'negan')
            ),
            array(
                'id'        => 'client',
                'type'      => 'text',
                'title'     => esc_html__('Client Name', 'negan')
            ),
            array(
                'id'        => 'timeline',
                'type'      => 'text',
                'title'     => esc_html__('Timeline', 'negan')
            ),
            array(
                'id'        => 'location',
                'type'      => 'text',
                'title'     => esc_html__('Location', 'negan')
            ),
            array(
                'id'        => 'website',
                'type'      => 'text',
                'title'     => esc_html__('Website', 'negan')
            )
        )
    );
    return $sections;
}
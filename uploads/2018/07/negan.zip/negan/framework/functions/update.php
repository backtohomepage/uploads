<?php

/**
 * This function allow get property of `woocommerce_loop` inside the loop
 * @since 1.1.7
 * @param string $prop Prop to get.
 * @param string $default Default if the prop does not exist.
 * @return mixed
 */

if(!function_exists('negan_get_wc_loop_prop')){
    function negan_get_wc_loop_prop( $prop, $default = ''){
        return isset( $GLOBALS['woocommerce_loop'], $GLOBALS['woocommerce_loop'][ $prop ] ) ? $GLOBALS['woocommerce_loop'][ $prop ] : $default;
    }
}

/**
 * This function allow set property of `woocommerce_loop`
 * @since 1.1.7
 * @param string $prop Prop to set.
 * @param string $value Value to set.
 */

if(!function_exists('negan_set_wc_loop_prop')){
    function negan_set_wc_loop_prop( $prop, $value = ''){
        if(isset($GLOBALS['woocommerce_loop'])){
            $GLOBALS['woocommerce_loop'][ $prop ] = $value;
        }
    }
}

/**
 * This function allow get property of `negan_loop` inside the loop
 * @since 1.1.7
 * @param string $prop Prop to get.
 * @param string $default Default if the prop does not exist.
 * @return mixed
 */

if(!function_exists('negan_get_theme_loop_prop')){
    function negan_get_theme_loop_prop( $prop, $default = ''){
        return isset( $GLOBALS['negan_loop'], $GLOBALS['negan_loop'][ $prop ] ) ? $GLOBALS['negan_loop'][ $prop ] : $default;
    }
}

remove_filter( 'woocommerce_product_loop_start', 'woocommerce_maybe_show_product_subcategories' );


if(!function_exists('negan_override_woothumbnail_size')){
    function negan_override_woothumbnail_size( $size ) {
        if(!function_exists('wc_get_theme_support')){
            return $size;
        }
        $size['width'] = absint( wc_get_theme_support( 'gallery_thumbnail_image_width', 100 ) );
        $cropping      = get_option( 'woocommerce_thumbnail_cropping', '1:1' );

        if ( 'uncropped' === $cropping ) {
            $size['height'] = '';
            $size['crop']   = 0;
        }
        elseif ( 'custom' === $cropping ) {
            $width          = max( 1, get_option( 'woocommerce_thumbnail_cropping_custom_width', '4' ) );
            $height         = max( 1, get_option( 'woocommerce_thumbnail_cropping_custom_height', '3' ) );
            $size['height'] = absint( round( ( $size['width'] / $width ) * $height ) );
            $size['crop']   = 1;
        }
        else {
            $cropping_split = explode( ':', $cropping );
            $width          = max( 1, current( $cropping_split ) );
            $height         = max( 1, end( $cropping_split ) );
            $size['height'] = absint( round( ( $size['width'] / $width ) * $height ) );
            $size['crop']   = 1;
        }

        return $size;
    }
    add_filter('woocommerce_get_image_size_gallery_thumbnail', 'negan_override_woothumbnail_size');
}

if(!function_exists('negan_override_filter_woocommerce_format_content')){
    function negan_override_filter_woocommerce_format_content( $format, $raw_string ){
        $format = preg_replace("~(?:\[/?)[^/\]]+/?\]~s", '', $raw_string);
        return apply_filters( 'woocommerce_short_description', $format );
    }
    add_filter('woocommerce_format_content', 'negan_override_filter_woocommerce_format_content', 99, 2);
}

if(!function_exists('negan_wc_product_loop')){
    function negan_wc_product_loop(){
        if(!function_exists('WC')){
            return false;
        }
        return have_posts() || 'products' !== woocommerce_get_loop_display_mode();
    }
}

if(!function_exists('negan_add_ajax_cart_btn_into_single_product')){
    function negan_add_ajax_cart_btn_into_single_product(){
        global $product;
        if($product->is_type('simple')){
            echo '<div class="wrap-single-addcart hidden">';
            woocommerce_template_loop_add_to_cart();
            echo '</div>';
        }
    }
    add_action('woocommerce_after_add_to_cart_button', 'negan_add_ajax_cart_btn_into_single_product');
}


if(!function_exists('negan_add_url_to_dropdown_product_category_widget')){
    function negan_add_url_to_dropdown_product_category_widget( $output, $r ){
        if( isset($r['taxonomy']) && $r['taxonomy'] == 'product_cat' ){
            $output = preg_replace_callback(
                '~<option.*?value=["\']+(.*?)["\']+~',
                function( $match ){
                    $return = $match[0];
                    if(!empty($match[1])){
                        $url = get_term_link($match[1], 'product_cat');
                        if(!is_wp_error($url)){
                            $return .= ' data-url="'. esc_attr($url) .'"';
                        }
                    }
                    return $return;
                },
                $output
            );
        }
        return $output;
    }
    add_filter('wp_dropdown_cats', 'negan_add_url_to_dropdown_product_category_widget', 20, 2);
}
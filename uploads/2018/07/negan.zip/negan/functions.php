<?php

/**
 * Require plugins vendor
 */

require_once get_template_directory() . '/plugins/tgm-plugin-activation/class-tgm-plugin-activation.php';
require_once get_template_directory() . '/plugins/plugins.php';

/**
 * Include the main class.
 */

include_once get_template_directory() . '/framework/classes/class-negan.php';


Negan::$template_dir_path   = get_template_directory();
Negan::$template_dir_url    = get_template_directory_uri();
Negan::$stylesheet_dir_path = get_stylesheet_directory();
Negan::$stylesheet_dir_url  = get_stylesheet_directory_uri();

/**
 * Include the autoloader.
 */
include_once Negan::$template_dir_path . '/framework/classes/class-autoload.php';

new Negan_Autoload();

/**
 * load functions for later usage
 */

require_once Negan::$template_dir_path . '/framework/functions/functions.php';

new Negan_Multilingual();

if(!function_exists('negan_init_options')){
    function negan_init_options(){
        Negan::$options = Negan_Options::get_instance();
    }
    negan_init_options();
}

if(!function_exists('Negan')){
    function Negan(){
        return Negan::get_instance();
    }
}

new Negan_Scripts();

new Negan_Admin();

new Negan_WooCommerce();

Negan_Visual_Composer::get_instance();

/**
 * Set the $content_width global.
 */
global $content_width;
if ( ! is_admin() ) {
    if ( ! isset( $content_width ) || empty( $content_width ) ) {
        $content_width = (int) Negan()->layout->get_content_width();
    }
}

require_once Negan::$template_dir_path . '/framework/functions/extra-functions.php';

require_once Negan::$template_dir_path . '/framework/functions/update.php';
<?php

global $negan_loop;

$tmp = $negan_loop;

$loop_layout = Negan()->settings->get('portfolio_display_type', 'grid');
$loop_style = Negan()->settings->get('portfolio_display_style', '1');

$negan_loop['loop_layout'] = $loop_layout;
$negan_loop['loop_style'] = $loop_style;
$negan_loop['responsive_column'] = Negan()->settings->get('portfolio_column', array('xlg'=> 1, 'lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1));
$negan_loop['image_size'] = Negan_Helper::get_image_size_from_string(Negan()->settings->get('portfolio_thumbnail_size', 'full'),'full');
$negan_loop['title_tag'] = 'h4';
$negan_loop['excerpt_length'] = 15;
$negan_loop['item_gap'] = (int) Negan()->settings->get('portfolio_item_space', 0);

echo '<div id="archive_portfolio_listing" class="la-portfolio-listing">';

if( have_posts() ){

    get_template_part("templates/portfolios/{$loop_layout}/start", $loop_style);

    while( have_posts() ){

        the_post();

        get_template_part("templates/portfolios/{$loop_layout}/loop", $loop_style);

    }

    get_template_part("templates/portfolios/{$loop_layout}/end", $loop_style);

}

echo '</div>';
/**
 * Display pagination and reset loop
 */

negan_the_pagination();

wp_reset_postdata();

$negan_loop = $tmp;
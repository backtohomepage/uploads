<?php

$header_layout = Negan()->layout->get_header_layout();

$show_cart      = (Negan_Helper::is_active_woocommerce() && Negan()->settings->get('header_show_cart') == 'yes' && Negan()->settings->get('catalog_mode', false) != 'on');
$show_wishlist  = (Negan_Helper::is_active_woocommerce() && Negan()->settings->get('header_show_wishlist') == 'yes' && function_exists('yith_wcwl_object_id'));
$show_search    = (Negan()->settings->get('header_show_search') == 'yes') ? true : false;
$show_account_menu      = (Negan()->settings->get('header_show_menu_account') == 'yes') ? true : false;
$show_hamburger_menu    = (Negan()->settings->get('header_show_menu_hamburger') == 'yes') ? true : false;

$show_header_top        = Negan()->settings->get('enable_header_top');
$header_top_elements    = Negan()->settings->get('header_top_elements', array());
$custom_header_top_html = Negan()->settings->get('use_custom_header_top');

$aside_sidebar_name = apply_filters('negan/filter/aside_widget_bottom', 'aside-widget');
?>
<?php if($show_hamburger_menu): ?>
<aside id="header_aside" class="header--aside">
    <div class="header-aside-wrapper">
        <a class="btn-aside-toggle" href="#"><i class="negan-icon-simple-close"></i></a>
        <div class="header-aside-inner">
            <?php if(is_active_sidebar($aside_sidebar_name)): ?>
                <div class="header-widget-bottom">
                    <?php
                    dynamic_sidebar($aside_sidebar_name);
                    ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</aside>
<?php endif;?>
<header id="masthead" class="site-header">
    <div class="la-header-sticky-height"></div>
    <?php if($show_header_top == 'custom' && !empty($custom_header_top_html) ): ?>
        <div class="site-header-top use-custom-html">
            <div class="container">
                <?php echo Negan_Helper::remove_js_autop($custom_header_top_html); ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if($show_header_top == 'yes' && !empty($header_top_elements) ): ?>
        <div class="site-header-top use-default">
            <div class="container">
                <div class="header-top-elements">
                    <?php
                    foreach($header_top_elements as $component){
                        if(isset($component['type'])){
                            echo Negan_Helper::render_access_component($component['type'], $component, 'header_component');
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="site-header-inner">
        <div class="container">
            <div class="header-main clearfix">
                <div class="header-left">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                            <figure class="logo--normal"><?php Negan()->layout->render_logo();?></figure>
                            <figure class="logo--transparency"><?php Negan()->layout->render_transparency_logo();?></figure>
                        </a>
                    </div>
                </div>
                <div class="header-middle">
                    <nav class="site-main-nav clearfix" data-container="#masthead .header-main">
                        <?php Negan()->layout->render_main_nav();?>
                    </nav>
                </div>
                <div class="header-right">
                    <?php if($show_account_menu): ?>
                        <div class="header__action header__action--account-menu header-toggle-account-menu">
                            <a href="#"><i class="negan-icon-users-circle-2"></i></a>
                            <?php
                            wp_nav_menu(array(
                                'container' => false,
                                'theme_location' => 'account-nav'
                            ));
                            ?>
                        </div>
                    <?php endif; ?>
                    <?php
                    if($show_wishlist){
                        $wishlist_page_id = yith_wcwl_object_id( get_option( 'yith_wcwl_wishlist_page_id' ) );
                        if($wishlist_page_id){
                            printf(
                                '<div class="header__action header__action--wishlist header-toggle-wishlist"><a href="%s"><i class="negan-icon-favourite-28"></i></a></div>',
                                esc_url(get_the_permalink($wishlist_page_id))
                            );
                        }
                    }
                    ?>
                    <?php if($show_cart): ?>
                        <div class="header__action header__action--cart header-toggle-cart">
                            <a href="<?php echo esc_url(wc_get_page_permalink('cart')) ?>"><i class="negan-icon-bag"></i><span class="la-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ) ?></span></a>
                        </div>
                    <?php endif; ?>

                    <?php if($show_search): ?>
                        <div class="header__action header__action--search header-toggle-search">
                            <a href="#"><i class="negan-icon-zoom"></i></a>
                        </div>
                    <?php endif; ?>

                    <?php if($show_hamburger_menu): ?>
                        <div class="header__action header__action--menu header-toggle-menu">
                            <a class="btn-aside-toggle" href="#"><i class="negan-icon-menu-left"></i></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- #masthead -->
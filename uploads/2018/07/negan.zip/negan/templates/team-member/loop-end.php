<?php
/*
 * Template loop-end
 */
global $negan_member_loop_index, $negan_loop;
$negan_member_loop_index = '';
$loop_style = isset($negan_loop['loop_style']) ? $negan_loop['loop_style'] : 1;
?>
</div>
<!-- .team-member-loop -->

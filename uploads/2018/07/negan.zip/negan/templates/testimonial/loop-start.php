<?php
global $negan_loop;
$loop_id = isset($negan_loop['loop_id']) ? $negan_loop['loop_id'] : uniqid('la-testimonial-');
$loop_style = isset($negan_loop['loop_style']) ? $negan_loop['loop_style'] : 1;
$responsive_column = isset($negan_loop['responsive_column']) ? $negan_loop['responsive_column'] : array('xlg'=> 1, 'lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1);
$slider_configs = isset($negan_loop['slider_configs']) ? $negan_loop['slider_configs'] : '';


$loopCssClass = array('la-loop','testimonial-loop la_testimonials');
$loopCssClass[] = 'loop-style-' . $loop_style;
$loopCssClass[] = 'la_testimonials--style-' . $loop_style;
$loopCssClass[] = 'loop--normal';
$loopCssClass[] = 'grid-items';
if(!empty($slider_configs)){
    $loopCssClass[] = 'la-slick-slider';
}else{
    foreach( $responsive_column as $screen => $value ){
        $loopCssClass[]  =  sprintf('%s-grid-%s-items', $screen, $value);
    }
}
?>
<div class="<?php echo esc_attr(implode(' ', $loopCssClass)) ?>"<?php
    if(!empty($slider_configs)){
        echo ' data-slider_config="'. esc_attr( $slider_configs ) .'"';
    }
?>>
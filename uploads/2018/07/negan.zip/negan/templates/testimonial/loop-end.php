<?php
/*
 * Template loop-end
 */
?>
</div>
<!-- .testimonial-loop -->
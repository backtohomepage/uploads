<?php
/*
 * Template loop-end
 */
?>
</div>
<!-- .posts-loop -->
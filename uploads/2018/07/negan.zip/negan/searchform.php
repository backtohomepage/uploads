<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
	<input autocomplete="off" type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search here&hellip;', 'placeholder', 'negan' ); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'negan' ); ?>" />
	<button class="search-button" type="submit"><i class="negan-icon-zoom2"></i></button>
</form>
<!-- .search-form -->
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

while ( have_posts() ) : the_post();

global $post, $product;
?>
<?php
	/**
	 * woocommerce_before_single_product hook.
	 *
	 * @hooked wc_print_notices - 10
	 */
	 do_action( 'woocommerce_before_single_product' );

	 if ( post_password_required() ) {
	 	echo get_the_password_form();
	 	return;
	 }
?>

<div id="product-<?php the_ID(); ?>" <?php post_class('la-p-single-wrap la-p-single-2'); ?>>

    <div class="row la-single-product-page">
        <div class="col-xs-12 col-md-6 p-left product-main-image">
            <div class="p---large">
                <?php

                $columns           = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
                $post_thumbnail_id = get_post_thumbnail_id( $post->ID );
                $full_size_image   = wp_get_attachment_image_src( $post_thumbnail_id, 'full' );
                $image_title       = get_post_field( 'post_excerpt', $post_thumbnail_id );
                $placeholder       = has_post_thumbnail() ? 'with-images' : 'without-images';
                $wrapper_classes   = apply_filters( 'woocommerce_single_product_image_gallery_classes', array(
                    'woocommerce-product-gallery--' . $placeholder,
                    'woocommerce-product-gallery--columns-' . absint( $columns ),
                    'images',
                ) );

                $product_design = Negan()->settings->get('woocommerce_product_page_design', 1);
                $wrapper_classes[] = 'la-woo-product-gallery';

                $_360_enable = get_post_meta( $product->get_id(), '_la_360_enable', true );

                ?>
                <div class="product--large-image">
                    <div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-columns="<?php echo esc_attr( $columns ); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
                        <figure class="woocommerce-product-gallery__wrapper">
                            <?php
                            $attributes = array(
                                'title'                   => $image_title,
                                'data-src'                => $full_size_image[0],
                                'data-large_image'        => $full_size_image[0],
                                'data-large_image_width'  => $full_size_image[1],
                                'data-large_image_height' => $full_size_image[2],
                            );

                            if ( has_post_thumbnail() ) {
                                $html  = '<div data-thumb="' . get_the_post_thumbnail_url( $post->ID, 'shop_thumbnail' ) . '" class="woocommerce-product-gallery__image"><a href="' . esc_url( $full_size_image[0] ) . '">';
                                $html .= get_the_post_thumbnail( $post->ID, 'shop_single', $attributes );
                                $html .= '</a></div>';
                            } else {
                                $html  = '<div class="woocommerce-product-gallery__image--placeholder">';
                                $html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src() ), esc_html__( 'Awaiting product image', 'negan' ) );
                                $html .= '</div>';
                            }

                            echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, get_post_thumbnail_id( $post->ID ) );

                            if($_360_enable != 'yes') {
                                do_action( 'woocommerce_product_thumbnails' );
                            }
                            ?>
                        </figure>
                        <div class="la_woo_loading"><div class="la-loader spinner3"><div class="dot1"></div><div class="dot2"></div><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>
                    </div>
                    <div id="la_woo_thumbs" class="la-woo-thumbs"><div class="la-thumb-inner"></div></div>
                </div>
            </div>
        </div><!-- .product--images -->
        <div class="col-xs-12 col-md-6 p-right product--summary">
            <div class="la-custom-pright">
                <div class="summary entry-summary">

                    <?php
                    /**
                     * woocommerce_single_product_summary hook.
                     *
                     * @hooked woocommerce_template_single_title - 5
                     * @hooked woocommerce_template_single_rating - 10
                     * @hooked woocommerce_template_single_price - 10
                     * @hooked woocommerce_template_single_excerpt - 20
                     * @hooked woocommerce_template_single_add_to_cart - 30
                     * @hooked woocommerce_template_single_meta - 50
                     */
                    do_action( 'woocommerce_single_product_summary' );
                    ?>
                </div>


            </div>
        </div><!-- .product-summary -->
    </div>

</div><!-- #product-<?php the_ID(); ?> -->
<?php do_action( 'woocommerce_after_single_product' ); ?>
<?php endwhile; ?>
 === Negan ===
Contributors: LA Studio
Requires at least: WordPress 4.9
Tested up to: WordPress 4.9.6, WooCommerce 3.4.3
Version: 1.2.4
Tags: one-column, two-columns, three-columns, left-sidebar, right-sidebar,  custom-background, custom-header, custom-menu, featured-images, flexible-header, full-width-template, post-formats, sticky-post, theme-options, translation-ready

== Description ==

Negan - Clean, Minimal WooCommerce Theme

* Mobile-first, Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* Mega Menu
* Post Formats

== Installation ==

1. Navigate to Appearance → Themes in your WordPress admin dashboard.
2. Click the Add New button at the top of the page then go for the Theme Upload option.
3. For the file upload, pick Theme Files / negan.zip in the theme package downloaded from ThemeForest and click Install Now.
4. Click Activate once the upload has finished.

== Copyright ==

Copyright 2015-2017 La-StudioWeb.com

== Changelog ==


------------ Version 1.2.4 Release [June 28, 2018]  ------------
# Fixed problem WooCommerce LightBox don't work correctly

File to changes
    wp-content/themes/negan/style.css
    wp-content/themes/negan/assets/admin/css/admin.css
    wp-content/themes/negan/assets/js/theme.js
    wp-content/themes/negan/assets/js/slick-slider/slick.js
    wp-content/themes/negan/assets/js/slick-slider/slick.min.js
    wp-content/themes/negan/framework/functions/update.php
    wp-content/themes/negan/framework/classes/class-helper.php

------------ Version 1.2.3 Release [June 28, 2018]  ------------
# Fixed PHP Fatal error: Uncaught Error
File to changes
    wp-content/themes/negan/style.css
    negan/framework/classes/class-woocommerce.php
    negan/plugins/lastudio-core.zip
    negan/plugins/plugins.php

------------ Version 1.2.2 Release [June 28, 2018]  ------------
# Fixed problem direct attributes link does not works
^ Compatibility with WooCommerce 3.4.3
^ Added option `Allow ajax add to cart on single product page and quickview popup` ( see on Appearance -> Theme Options -> WooCommerce -> Product Page Setting )
^ Added option turn on/off WooCommerce Zoom & LightBox ( see on Appearance -> Theme Options -> WooCommerce -> Product Page Setting )
^ Added option allow choose product gallery columns on single product page  ( see on Appearance -> Theme Options -> WooCommerce -> Product Page Setting )
^ Added option allow sharing post/product on Whatapps and Telegram
^ Update latest version of Lightcase, Slick Slider jquery plugins
^ Update version of Revolution Slider, WPBakery Visual Composer, LaStudio Core plugin

File to changes
    negan/style.css
    negan/assets/js/theme.js
    negan/assets/js/lightcase/lightcase.js
    negan/assets/js/lightcase/lightcase.min.js
    negan/assets/js/slick-slider/slick.js
    negan/assets/js/slick-slider/slick.min.js
    negan/woocommerce/content-single-quickview.php
    negan/framework/classes/class-scripts.php
    negan/framework/configs/options/woocommerce.php
    negan/framework/classes/class-init.php
    negan/framework/functions/extra-functions.php
    negan/framework/configs/options/social_media.php
    negan/framework/functions/functions.php
    negan/plugins/plugins.php
    negan/plugins/revslider.zip
    negan/plugins/lastudio-core.zip
    negan/plugins/js_composer.zip


------------ Version 1.2.1 Release [June 09, 2018]  ------------
* Compatibility with PHP 7.2
^ Update version of WPBakery Visual Composer, LaStudio Core plugins
File to change
    negan/style.css
    negan/single.php
    negan/templates/team-member/loop-2.php
    negan/framework/classes/class-woocommerce.php
    negan/plugins/plugins.php
    negan/plugins/lastudio-core.zip
    negan/plugins/js_composer.zip
    negan/framework/functions/extra-functions.php

------------ Version 1.2.0 Release [June 01, 2018]  ------------
* Compatibility with WordPress 4.9.6
* Compatibility with WooCommerce 3.4.1
# Fixed shop masonry does not display correctly when calling via Ajax
# Fixed multiple links problem for posts/products/pages ...
# Fixed Instagram Feeds does not display correctly when slider option is enabled
# Fixed problem can't linked in custom block on MegaMenu
# Click behavior on iOS device
^ Update version of Revolution Slider, WPBakery Visual Composer, LaStudio Core plugin

changelog
    Files to change
        negan/style.css
        negan/assets/js/theme.js
        negan/framework/functions/extra-functions.php
        negan/framework/classes/widget/class-widget-price-filter-list.php
        negan/woocommerce/loop/orderby.php
        negan/woocommerce/loop/toolbar.php
        negan/framework/configs/options/additional_code.php

        negan/woocommerce/archive-product.php
        negan/framework/functions/update.php
        negan/woocommerce/content-product.php
        negan/woocommerce/content-single-product.php
        negan/woocommerce/global/quantity-input.php
        negan/woocommerce/myaccount/form-login.php

        negan/plugins/plugins.php
        negan/plugins/revslider.zip
        negan/plugins/js_composer.zip
        negan/plugins/lastudio-core.zip


    Files to remove
        negan/woocommerce/checkout/terms.php


------------ Version 1.1.8 Release [February 26, 2018]  ------------
* Compatibility with WooCommerce 3.3.3
^ Add close filter button on mobile
^ Update version of Revolution Slider
changelog
    Files to change
        negan/style.css
        negan/woocommerce/single-product/product-image.php
        negan/woocommerce/single-product/product-thumbnails.php
        negan/plugins/revslider.zip
        negan/plugins/plugins.php
        negan/woocommerce/loop/toolbar.php
        negan/assets/js/theme.js

------------ Version 1.1.7 Release [February 08, 2018]  ------------
* Compatibility with WordPress 4.9.4
* Compatibility with WooCommerce 3.3.1
# Fixed: Remove ghost height of megamnu when hovered on a link
# Fixed: Global layout for page
^ Update version of Revolution Slider, LaStudio Core
changelog
    Files to change
        negan/style.css
        negan/functions.php
        negan/dokan/store.php
        negan/plugins/plugins.php
        negan/plugins/revslider.zip
        negan/plugins/lastudio-core.zip
        negan/framework/functions/update.php
        negan/framework/classes/class-setting.php
        negan/framework/classes/class-woocommerce.php
        negan/framework/configs/options/woocommerce.php
        negan/woocommerce/product-searchform.php
        negan/woocommerce/myaccount/form-login.php
        negan/woocommerce/loop/orderby.php
        negan/woocommerce/global/quantity-input.php
        negan/woocommerce/loop/add-to-cart.php
        negan/woocommerce/loop/loop-start.php
        negan/woocommerce/archive-product.php



------------ Version 1.1.6 Release [January 17, 2018]  ------------
* Compatibility with WordPress 4.9.2
* Compatibility with WooCommerce 3.2.6
# Fixed issue can't override sidebar on the product category page
# Fixed issue the price slider does not working when called ajax shop
# Fixed issue images can't crop when using the JetPack plugin
# Fixed issue "Clear All Filter" does not work perfectly
^ Update version of Visual Composer, Revolution Slider, LaStudio Core, Negan Package Demo Data ...

changelog
    Files to change
        negan/style.css
        negan/plugins/plugins.php
        negan/plugins/js_composer.zip
        negan/plugins/revslider.zip
        negan/plugins/lastudio-core.zip
        negan/plugins/negan-demo-data.zip
        negan/framework/classes/class-woocommerce.php
        negan/woocommerce/checkout/terms.php
        negan/framework/classes/class-helper.php
        negan/assets/js/theme.js


------------ Version 1.1.5 Release [October 16, 2017]  ------------
#Tweak RTL language version
#Tweak option "Override Sidebar" does not work perfectly
* Compatibility with WooCommerce 3.2.1
^ Added option "Enable Header Sticky"
^ Update version of Visual Composer, Revolution Slider, LaStudio Core ...
^ Update language file

changelog
    Files to change
        negan/framework/classes/class-woocommerce.php
        negan/framework/classes/class-visual-composer.php
        negan/framework/classes/class-layout.php
        negan/framework/classes/class-template.php
        negan/framework/configs/options/header.php
        negan/framework/configs/options/fonts.php
        negan/languages/negan.pot
        negan/style.css
    Files to remove
        negan/woocommerce/checkout/thankyou.php
        negan/woocommerce/cart/cart-shipping.php
        negan/woocommerce/cart/shipping-calculator.php


------------ Version 1.1.4 Release [September 11, 2017]  ------------
#Tweak: Instagram Feed shortcode
^Add option change background color for page loader
^Update language file

------------ Version 1.1.3 Release [September 09, 2017]  ------------
#Remove woocommerce.php file in folder theme
#Fixed: Sale Products, Best Selling Products, Featured Product, Recent Products Shortcode does not work correctly
#Fixed: "Back to top" option does not work
#Fixed: Double click on links set by default
^Update: Revolution Slider, LaStudio Core plugins
^Add transition effect to the mobile menu

------------ Version 1.1.2 Release [August 22, 2017]  ------------
* Compatibility with WordPress 4.8.1
* Compatibility with WooCommerce 3.1.2
* Compatibility with VC Vendors & Dokan plugins
#Fixed: Theme setting for Portfolio does not work
#Fixed: Color Swatches plugins
^Update version of Visual Composer, Revolution Slider ...
^Update language file
^Added option FullWidth for MegaMenu
^Added option hide breadcrumbs, page title for single product

------------ Version 1.1.1 Release [August 10, 2017]  ------------
#Fixed: Variations product does not work on quickview
#Fixed: Typekit enqueue incorrectly
^Added: Ajax Shop Filter

------------ Version 1.1 Release [August 03, 2017]  ------------
#Fixed: Compare button on product list
#Fixed: Missing custom 404 page content
#Fixed scroll product single style 2
#Fixed sidebar option don't work on meta box
^Add header sticky on mobile
^Add option manager item in footer bar menu
^Add more single product layout ( layout 04, layout 05 )
^Add mobile header layout
^Update version of Color Swatches


------------ Version 1.0.1 Release [July 19, 2017]  ------------

#Fixed - Maintenance function unavailable
*Fixed - Disable breadcrumbs don't working on the blog page
*Tweak - Compatibility YITH Compare,YITH Wishlist
* Compatibility with WooCommerce 3.1.1
^ Add setting height for header container
^ Add setting show menu footer accessibility on mobile
^ Add Header Layout 7 ( Menu + Logo + Access Icon )
^ Make wishlist icon clickable on mobile
^ Make the product simple style 2 same layout on tablet & desktop
^ Make the megamenu available on the tablet
^ Update Document


------------ Version 1.0 Release [June 26, 2017]  ------------
* Release

Initial release